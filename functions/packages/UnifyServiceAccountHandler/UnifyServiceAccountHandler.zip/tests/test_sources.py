import unittest
from unify.sources import Sources
from unify.sources import Sources
import json
import os
import uuid
from tests import *


class TestSources(unittest.TestCase):
    sources = Sources(cluster_name, props)
    dataset_name = 'test-{}'.format(str(uuid.uuid4()))
    result = sources.create_api_data_set_with_content(
        dataset_name,
        test_org,
        'c1,c2\nf1,f2'
    )
    dataset_id = result['data_set_id']

    def test_label(self):
        labels = ['python sdk test']
        raised = False
        try:
            self.sources.label(test_org, self.dataset_id, labels)
        except:
            raised = True
        self.assertFalse(raised, 'Exception raised in label dataset')
    


