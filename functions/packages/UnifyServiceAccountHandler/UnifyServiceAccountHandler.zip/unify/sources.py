"""
Unify datasets client
"""
import json
import time
import uuid
import os
from tempfile import mkstemp

from unify.properties import Properties, ClusterSetting
from .apirequestsmng import ApiRequestManager
from .generalutils import csv_to_json
from .generalutils import json_to_csv
from .generalutils import create_schema_dataset
from .generalutils import stream_iterable
from .WaitingLibrary import Wait


class Sources(ApiRequestManager):
    """
    File that contains methods to interact with the dataset api endpoints
    """

    def __init__(self, cluster=None, props=Properties(ClusterSetting.KEY_RING)):
        """
        Class constructor
        :param cluster: Cluster name
        :param props: Instantiated Properties class
        """

        super().__init__(cluster=cluster, props=props)

        self.epoch_time = int(time.time())
        self.pi_tag_export_limit = {"piTagExportLimit": 999}
        self.expiry = {"expiry": 999}

        try:

            self.list_templates_uri = 'api/assetTemplates'
            self.upload_content_type_header = {"Content-Type": "multipart/form-data"}
            self.delete_content_type_header = {"Content-Type": "application/json"}

            self.epoch_time = int(time.time())
            self.sources_url = self.props.get_remote(self.cluster) + "io/v1/org/{}/sources"

            self.agents_url = self.props.get_remote(self.cluster) + "agents/v2/"

            self.piwebapi_test_url = self.agents_url + "piwebapi/org/{}/test"

            self.piwebapi_create_url = self.agents_url + \
                "piwebapi/org/{}/create?modeldata_only=true"

            self.piconfig_upload_url = self.agents_url + "piconfig/org/{}/model/?name=&serverName="

            self.piconfig_upload_url_no_params = self.agents_url + "piconfig/org/{}/model/"

            self.staticfile_upload_url = self.agents_url + "staticfile/org/{}/model"

            self.delete_source_url = self.sources_url + "/{}"

            self.delete_evergreening_source_url = self.agents_url + "piwebapi/org/{}/source/{}"

            self.stage_file_url = self.props.get_remote(self.cluster) + "datasets/v1/stage/file"

            self.post_data_set_schema_url = self.props.get_remote(
                self.cluster) + "datasets/v1/dataset"

            self.commit_data_set_url = self.props.get_remote(
                self.cluster) + "datasets/v1/dataset/{}/commit"

            self.labeling_sources = self.props.get_remote(
                self.cluster) + "datasets/v1/labeling"

            self.labeling_sources_2 = self.props.get_remote(
                self.cluster) + "datasets/v1/labeling/query"

            self.labeling_sources_facets_url = self.props.get_remote(
                self.cluster) + "datasets/v1/labeling/facets"

            self.append_url = self.props.get_remote(
                self.cluster) + "agents/v2/staticfile/org/{}/model/{}/append"

            self.download_dataset_url = self.props.get_remote(
                self.cluster) + "tags/org/{}/datasets/{}/download"

            self.get_commit = self.commit_data_set_url + "/{}"

        except Exception as error:
            raise error

    def get_status(self, org_id, dataset_id, commit_id):
        """
        Retrieve the status of the given commit id
        :param org_id: org where the commit has occured
        :param dataset_id: datasets id of whom the commit belongs to
        :param commit_id: commit id to be retrieved
        :return:
        """
        return self.get_commit_status(org_id=org_id, data_set_id=dataset_id, commit_id=commit_id)[0]

    def accert_status(self, org_id, dataset_id, commit_id, expected):
        """
        Method accerts if the status of a given commit is what is expected
        :param org_id: org where the commit has occurred
        :param dataset_id: datasets id of whom the commit belongs to
        :param commit_id: commit id to be retrieved
        :param expected: Expected status
        :return:
        """
        status = self.get_status(org_id=org_id, dataset_id=dataset_id, commit_id=commit_id)

        if "status" in status:

            tipe = status["status"]

            if "$type" in tipe:
                return expected in tipe["$type"]

        return False

    def is_commit_completed(self, org_id, dataset_id, commit_id):
        """
        Verifies if the status of the commit sis completed
        :param org_id: org where the commit has occurred
        :param dataset_id: datasets id of whom the commit belongs to
        :param commit_id: commit id to be asserted
        :return:
        """
        return self.accert_status(
            org_id=org_id,
            dataset_id=dataset_id,
            commit_id=commit_id,
            expected="Completed"
        )

    def upload_big_dataset(
            self, name, org_id, content, format="csv",
            convertToParquet="false", encoding='UTF-8',chunks=10000):
        """
        Method to upload a data-set through the static route, this method should be used when the
        uploading a big file. It will split the file into
        smaller chunks and upload them sequentially
        :param name: data-set name to be cerated
        :param org_id: Org where the data-set will be created
        :param content: dataset content
        :param format: csv or tsv
        :param convertToParquet:
        :param encoding: File encoding
        :param chunks: chunks that the entire file will be splinted
        :return:
        """

        data = content.encode(encoding)

        jdata = csv_to_json(data)

        first = True

        dataset_data = {
            "create": {},
            "append": []
        }
        for aux_file in stream_iterable(container=jdata, chunk=chunks):

            if first:

                first = False

                file_dir, path = mkstemp(suffix=".csv")

                open(path, "w+").write(json_to_csv(aux_file))

                dataset_data["create"] = self.create_api_data_set(
                    name=name,
                    org_id=org_id,
                    file_path=path,
                    format=format,
                    convertToParquet=convertToParquet,
                    encoding=encoding
                )

                Wait().until(
                    self.is_commit_completed,
                    "commit {} never completed".format(dataset_data["create"]["data_set_id"]),
                    org_id,
                    dataset_data["create"]["data_set_id"],
                    dataset_data["create"]["commit_id"]
                )

                os.close(file_dir)

            else:

                file_dir, path2 = mkstemp(suffix=".csv")

                open(path2, "wb").write(json_to_csv(aux_file).encode(encoding))

                try:
                    added_data = self.add_data_to_existing_source(
                        name="{} {}".format(name, str(uuid.uuid4())[:4]),
                        org_id=org_id,
                        data_set_id=dataset_data["create"]["data_set_id"],
                        file_path=path2,
                        group_id=dataset_data["create"]["group_id"]
                    )

                    Wait().until(
                        self.is_commit_completed,
                        "commit {} never completed".format(dataset_data["create"]["data_set_id"]),
                        org_id,
                        dataset_data["create"]["data_set_id"],
                        added_data["commit_id"]
                    )

                    dataset_data["append"].append(added_data)

                    os.close(file_dir)

                except Exception as err:
                    print(err)
                    open("fail_{} {}.csv".format(name, str(uuid.uuid4())[:4]), "wb").write(
                        json_to_csv(aux_file).encode("utf-8"))

        return dataset_data

    def create_api_data_set(
            self, name, org_id, file_path, format="csv",
            convertToParquet="false", encoding="UTF-8"):
        """
        Creates a dataset through the static file route
        :param name: Name to of the new dataset
        :param org_id: Org id where the data--set will ne stored
        :param file_path: Directory file path where the data-set contents are
        :param format: csv or tsv
        :param convertToParquet:
        :param encoding: file_path encoding
        :return:
        """

        content = open(file_path, "r+").read()

        return self.create_api_data_set_with_content(
            name,
            org_id,
            content,
            format,
            convertToParquet,
            encoding
        )

    def create_api_data_set_with_content(
            self,
            name,
            org_id,
            content,
            format="csv",
            convertToParquet="false",
            encoding="UTF-8"):
        """
        Creates a dataset through the static file route
        :param name: Name to of the new dataset
        :param org_id: Org id where the data--set will ne stored
        :param content: dataset contenten in csv or tsv format
        :param format: csv or tsv
        :param convertToParquet:
        :param encoding: ile_path encoding
        :return:
        """
        results = {}

        stage_result = self.stage_file_with_content(
            name=name,
            org_id=org_id,
            file_data=content,
            format=format,
            convertToParquet=convertToParquet,
            encoding=encoding
        )

        results["group_id"] = stage_result

        schema = create_schema_dataset(
            csv_data=content,
            name=name
        )
        initial_commit = self.post_file_schema(
            org_id=org_id,
            schema_data=json.dumps(schema),
        )

        results["data_set_id"] = initial_commit["id"]

        second_commit = self.append_command(
            org_id=org_id,
            data_set_id=results["data_set_id"],
            name=name,
            group_id=results["group_id"]
        )

        results.update(second_commit)

        return results

    def get_commit_status(self, org_id, data_set_id, commit_id):
        """
        Retrieve the status of the given commit id
        :param org_id: org where the commit has occured
        :param dataset_id: datasets id of whom the commit belongs to
        :param commit_id: commit id to be retrieved
        :return:
        """
        header = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id,
            others={"'Content-Type'": "application/data"}
        )

        url = self.get_commit.format(data_set_id, commit_id)

        test_request = self.session.get(url, headers=header)

        return json.loads(test_request.content.decode('utf8')), test_request.status_code

    def download_dataset_content(self, org_id, dataset_id):
        """
        Downloads the content of a given dataset
        :param org_id: Org id where the dataset exists
        :param dataset_id: Dataset id to be retrieved
        :return:
        """
        header = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id
        )

        get_source_request = self.session.get(
            self.download_dataset_url.format(org_id, dataset_id),
            headers=header
        )

        if get_source_request.status_code == 200:
            return get_source_request.content

        raise Exception(repr(get_source_request.content))

    def create_export_dataset(self, org_id, dataset_ids):
        """
        Create the content needed to export a data-set,
        this is usually used when using the import dataset
        :param org_id: Org where the dataset exists
        :param dataset_ids: array containing the dataset ids
        :return:
        """
        datasets = self.get_sources(org_id=org_id)

        id_to_type = {}

        for dataset in datasets:
            id_to_type[dataset["id"]] = dataset

        all_datasets = []
        for dataset_id in dataset_ids:

            if dataset_id not in id_to_type:
                continue

            info = id_to_type[dataset_id]

            source_type = "Upload"

            if "ean.source_type" in info["fields"]:
                source_type = info["fields"]["ean.source_type"]

            get_source_request = self.download_dataset_content(org_id=org_id, dataset_id=dataset_id)

            result = {
                "component": None,
                "id": dataset_id,
                "schema": info["fields"]["schema"],
                "name": id_to_type[dataset_id]["name"],
                "type": source_type,
                "file_content": csv_to_json(csv_data=get_source_request)
            }

            all_datasets.append(result)

        return json.dumps(all_datasets)

    def add_data_to_existing_source(
            self, name, org_id, file_path,
            data_set_id, group_id, format="csv"):
        """
        Helper function to append data to existing dataset
        :param name: Name of the current file, used for staging the file
        :param org_id: Org where the target data-set exists
        :param file_path: Directory file path that contains the data to be appended
        :param data_set_id: Dataset id where the content will be appended
        :param group_id:  group identification that the data-set belongs
        :param format: csv or tsv
        :return:
        """
        results = {}

        second_stage = self.stage_data(
            name=name,
            org_id=org_id,
            file_path=file_path,
            groupId=group_id,
            format=format
        )

        results["group_id"] = second_stage

        final_commit = self.append_command(
            org_id=org_id,
            data_set_id=data_set_id,
            name=name,
            group_id=results["group_id"]
        )

        results.update(final_commit)

        return results

    def overwrite_dataset(
            self, org_id, data_set_id, file_path, groupId=None,
            format="csv", convertToParquet="false"):

        """
        Overwites the contents of the given dataset with new content
        :param org_id: Org where the target data-set exists
        :param data_set_id: Dataset id that its content will be over writen
        :param file_path: Directory file path that contains the data to be appended
        :param groupId: group identification that the data-set belongs
        :param format: csv or tsv
        :param convertToParquet:
        :return:
        """
        response = {}

        response["truncate"] = self.truncate_data_set(
            org_id=org_id,
            data_set_id=data_set_id
        )[0]

        name = "overwirte{}".format(int(time.time()))

        response["stage"] = self.stage_file(
            name=name,
            org_id=org_id,
            file_path=file_path,
            groupId=groupId,
            format=format,
            convertToParquet=convertToParquet
        )[0]

        response["append"] = self.append_command(
            org_id=org_id,
            data_set_id=data_set_id,
            group_id=response["stage"],
            name=name
        )[0]

        return response


    def _commit_dataset_command(self, org_id, data_set_id, command):
        header = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id,
            others={"'Content-Type'": "application/data"}
        )
        headers = dict(header.items())
        request = self.session.post(
            self.commit_data_set_url.format(data_set_id),
            headers=headers,
            json=command
        )

        if request.status_code in [200, 202]:
            return json.loads(request.content)
        else:
            raise Exception(repr(request.content))

    def truncate_data_set(self, org_id, data_set_id):
        """
        Truncates the dataset content
        :param org_id: Org where the target data-set exists
        :param data_set_id:  Dataset id where which contents will be truncated
        :return:
        """
        command = {"commands": [{"$type": "truncate", "cause": []}]}
        return self._commit_dataset_command(org_id, data_set_id, command)


    def append_dataset(self, org_id, data_set_id, content):
        """
        Appends data to existing dataset
        :param org_id: Org where the target data-set exists
        :param data_set_id: Dataset id where the content will be appended
        :param content: data content that will be added to the dataset
        :return:
        """
        file_dir, path = mkstemp(suffix=".csv")

        open(path, "wb").write(content.encode())

        os.close(file_dir)

        headers = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id
        )

        files = {'file': open(path, "rb")}

        post_upload_file = self.session.post(
            self.append_url.format(org_id, data_set_id),
            headers=headers,
            files=files
        )

        if post_upload_file.status_code in [200, 201, 202]:
            response = json.loads(post_upload_file.content)

            return response

        raise Exception(repr(post_upload_file.content))

    def label(self, org_id, data_set_id, labels):
        command = {
            "commands":
                [
                    {
                        "$type": "text-label-group",
                        "key": "ean.facets",
                        "values": labels,
                        "cause": [],
                    }
                ]
        }
        return self._commit_dataset_command(org_id, data_set_id, command)

    def append_command(self, org_id, data_set_id, group_id, name):
        """
        Executes append command to a staged file ona group id
        :param org_id:  Org where the target data-set exists
        :param data_set_id: Dataset id to be appended
        :param group_id: group identification that the data-set belongs
        :param name: name of the staged file
        :return:
        """
        command = {
            "commands":
                [
                    {
                        "$type": "append",
                        "name": repr(name),
                        "group": group_id.decode(),
                        "cause": []
                    }
                ]
        }
        return self._commit_dataset_command(org_id, data_set_id, command)


    def stage_data(
            self, name, org_id, file_path, groupId=None, format="csv",
            convertToParquet="false", encoding='UTF-8', encode=False):
        """
        Stage data to agiven org and group id
        :param name: name of the staged file
        :param org_id: Org where the target data-set exists
        :param file_path: Directory file path with files to be staged
        :param groupId: group identification that the data-set belongs
        :param format: csv or tsv
        :param convertToParquet:
        :param encoding: Datset file encoding
        :param encode: Encode the data-set with given encoding
        :return:
        """
        header = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id
        )

        header.update({"'Content-Type'": "application/octet-stream"})

        headers = dict(header.items())

        if groupId is None:
            payload_data = {
                "name": repr(name),
                "convertToParquet": convertToParquet,
                "format": format
            }
        else:
            payload_data = {
                "name": repr(name),
                "convertToParquet": convertToParquet,
                "format": format,
                "groupId": groupId
            }

        file_data = open(file_path, "r").read().encode(encoding)

        test_request = self.session.post(
            self.stage_file_url,
            headers=headers,
            data=file_data,
            params=payload_data
        )

        return test_request.content

    def stage_file(self, name, org_id, file_path, groupId=None, format="csv",
                   convertToParquet="false", encoding='UTF-8', encode=False):
        """
        Stage data from file to a given org and group id
        :param name: name of the staged file
        :param org_id: Org where the target data-set exists
        :param file_path: Directory file path with files to be staged
        :param groupId: group identification that the data-set belongs
        :param format: csv or tsv
        :param convertToParquet:
        :param encoding: Datset file encoding
        :param encode: Encode the data-set with given encoding
        :return:
        """

        file_data = open(file_path, "r").read().encode(encoding)

        return self.stage_file_with_content(
            name=name,
            org_id=org_id,
            file_data=file_data,
            groupId=groupId,
            format=format,
            convertToParquet=convertToParquet,
            encoding=encoding,
            encode=encode
        )

    def stage_file_with_content(
            self, name, org_id, file_data, groupId=None,
            format="csv", convertToParquet="false", encoding='UTF-8', encode=False
    ):
        """
        Stage data from content to a given org and group id
        :param name: name of the staged file
        :param org_id: Org where the target data-set exists
        :param file_data: content with data to be staged
        :param groupId: group identification that the data-set belongs
        :param format: csv or tsv
        :param convertToParquet:
        :param encoding: Datset file encoding
        :param encode: Encode the data-set with given encoding
        :return:
        """
        header = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id
        )

        header.update({"'Content-Type'": "application/octet-stream"})

        headers = dict(header.items())

        if groupId is None:

            payload_data = {
                "name": repr(name),
                "convertToParquet": convertToParquet,
                "format": format
            }
        else:
            payload_data = {
                "name": repr(name),
                "convertToParquet": convertToParquet,
                "format": format,
                "groupId": groupId
            }

        test_request = self.session.post(
            self.stage_file_url,
            headers=headers,
            data=file_data,
            params=payload_data
        )

        return test_request.content

    def post_file_schema(self, org_id, schema_data, encoding='UTF-8'):
        """
        Post the schema of a file to be staged
        :param org_id: org where the file is going to be staged
        :param schema_data: file schema
        :param encoding: file encoding
        :return:
        """

        header = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id,
            others={"'Content-Type'": "application/data"}
        )

        headers = dict(header.items())

        schema_request = self.session.post(
            self.post_data_set_schema_url,
            headers=headers,
            data=schema_data
        )

        if schema_request.status_code == 200:
            return json.loads(schema_request.content)

        raise Exception(repr(schema_request.content))

    def pi_config_upload(self, name, server_name, file_path, org_id):
        """
        DEPRECATED - Use static_file_upload instead! This method may be removed
        in the future on a major version bump.

        Upload PI-CONFIG dataset
        :param name: dataset name
        :param server_name: PI-Config data archive server name
        :param file_path: Directory file path with files to be uploaded
        :param org_id: Org where the dataset will be created
        :return:
        """

        headers = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id
        )

        upload_file = {'file': open(file_path, "rb")}

        query_strings = {"name": str(name), "serverName": str(server_name)}

        post_upload_pitag = self.session.post(
            self.piconfig_upload_url_no_params.format(org_id),
            params=query_strings,
            headers=headers,
            files=upload_file
        )

        if post_upload_pitag.status_code == 200:
            return json.loads(post_upload_pitag.content)

        raise Exception(repr(post_upload_pitag.content))

    def static_file_upload(self, name, content, org_id):
        """
        Static file upload from content
        :param name: Dataset name to be created
        :param content: Dataset content stored in a variable
        :param org_id: Org where the dataset will be created
        :return:
        """

        static_file_upload_url = self.staticfile_upload_url

        query_strings = {"name": str(name)}

        headers = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id
        )

        files = {'file': open(content, "rb")}

        post_upload_file = self.session.post(
            static_file_upload_url.format(org_id),
            headers=headers,
            files=files,
            params=query_strings
        )

        if post_upload_file.status_code == 200:
            return json.loads(post_upload_file.content)

        raise Exception(repr(post_upload_file.content))

    def get_sources(self, org_id):
        """
        Retrieves all the metadata of datasets on an org
        :param org_id: Org to be queried
        :return:
        """

        header = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id,
            others=self.delete_content_type_header
        )

        if self.evergreen_enabled:

            query_strings = {
                "ean.orgs": org_id,
                "_fields": "schema,ean.ready,ean.source_type"
            }

            get_sources_request = self.session.get(
                self.labeling_sources_2,
                headers=header,
                params=query_strings
            )

            content = json.loads(get_sources_request.content.decode('utf8'))
        else:

            get_sources_request = self.session.get(self.sources_url.format(org_id), headers=header)

            content = json.loads(get_sources_request.content)

        if get_sources_request.status_code == 200:
            return content

        raise Exception(repr(get_sources_request.content))

    def get_sources_by_labels(self, org_id, facets):
        """
        Retieves all datasets that matches given labels
        :param org_id:
        :param facets: facet strings, example: ["facet1", "facet2"]
        :return:
        """

        header = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id,
            others=self.delete_content_type_header
        )

        query_strings = {
            "facet": facets
        }

        get_sources_request = self.session.get(
            self.labeling_sources_facets_url,
            headers=header,
            params=query_strings
        )

        content = json.loads(get_sources_request.content)

        if get_sources_request.status_code == 200:
            return content

        raise Exception(repr(get_sources_request.content))
