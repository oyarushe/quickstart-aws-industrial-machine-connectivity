"""
This is a helper library that gives waiting methods
"""
import time
POLL_FREQUENCY = 2  # How long to sleep in between
IGNORED_EXCEPTIONS = ()  # exceptions ignored during calls to the method
TIME_OUT = 10


class Wait:
    """
    Unify wait library
    """

    def __init__(self, timeout=TIME_OUT, poll_frequency=POLL_FREQUENCY, ignored_exceptions=None):
        """
        Unify wait library constuctor
        :param timeout: Max time to wait before timeout
        :param poll_frequency: How often the method should be verified
        :param ignored_exceptions:
        """

        self._timeout = timeout
        self._poll = poll_frequency

        if self._poll == 0:
            self._poll = POLL_FREQUENCY

        exceptions = list(IGNORED_EXCEPTIONS)

        if ignored_exceptions is not None:

            try:
                exceptions.extend(iter(ignored_exceptions))

            except TypeError:

                exceptions.append(ignored_exceptions)

        self._ignored_exceptions = tuple(exceptions)

    def until(self, method, message='', *args):
        """
        Method to wait for method to return TRUE
        :param method: pointer to a python method
        :param message: String message to return if method times out
        :param args: Additional args to be passed to method
        :return:
        """

        end_time = time.time() + self._timeout
        while True:
            try:
                value = method(*args)
                if value:
                    return value
            except self._ignored_exceptions as exc:
                message += str(getattr(exc, 'stacktrace', None))
                break

            time.sleep(self._poll)
            if time.time() > end_time:
                break
        raise Exception(message)

    def until_not(self, method, message='', *args):
        """
        Negate until
        :param method: pointer to a python method
        :param message: String message to return if method times out
        :param args: Additional args to be passed to method
        :return:
        """

        end_time = time.time() + self._timeout

        while True:
            try:
                value = method(*args)
                if not value:
                    return value
            except self._ignored_exceptions as exc:
                message += str(getattr(exc, 'stacktrace', None))
                break

            time.sleep(self._poll)

            if time.time() > end_time:
                break

        raise Exception(message)

    def until_backoff(self, method, message='', *args):
        """
        Wait until with exponential backoff
        :param method: pointer to a python method
        :param message: String message to return if method times out
        :param args: Additional args to be passed to method
        :return:
        """
        end_time = time.time() + self._timeout

        new_poll = self._poll

        while True:
            try:
                value = method(*args)
                if value:
                    return value
            except self._ignored_exceptions as exc:
                message += str(getattr(exc, 'stacktrace', None))
                break

            time.sleep(new_poll)

            new_poll *= 0.02

            if time.time() > end_time:
                break
        raise Exception(message)
