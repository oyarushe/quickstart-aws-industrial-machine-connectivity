"""
This script has sume utility support methods for export and import workflows
"""
import json
import os.path
import uuid

from tempfile import mkstemp

from unify.properties import ClusterSetting
from unify.orgadmin import OrgAdmin
from unify.properties import Properties
from unify.templates import Templates
from unify.pipelines import Pipelines
from unify.sources import Sources
from unify.generalutils import json_to_csv
from unify.generalutils import csv_to_json
from unify.apiutils import remove_special
from unify.assetaccess import AssetAccess



class ApiManager:
    """
    This class contains most of the import and import data
    """

    def __init__(self, cluster=None, props=Properties(ClusterSetting.KEY_RING)):
        try:

            self.properties = props

            self.evergreen_enabled = self.properties.get_asset_sync(cluster=cluster)

            self.orgs = OrgAdmin(cluster=cluster, props=self.properties)

            self.templates = Templates(cluster=cluster, props=self.properties)

            self.pipelines = Pipelines(cluster=cluster, props=self.properties)

            self.sources = Sources(cluster=cluster, props=self.properties)

            self.cluster = cluster

            self.sources.evergreen_enabled = self.evergreen_enabled

            self.pipelines.evergreen_enabled = self.evergreen_enabled

        except Exception as error:
            raise error

    def import_source(self, content, orgid, name, type, encoding="UTF-8", chunks=10000):
        """
        Method to import source given the content on a variable
        :param content: CSV or TSV file content
        :param orgid: ORg where the source will be imported
        :param name: Name to be given to the datasource
        :param type: Type of the dataset
        :param encoding: File encoding
        :param chunks: when used on type generic,
        chunks the amount of lines that the file will be partitioned
        :return:
        """
        if type == "external":

            file_dir, path = mkstemp(suffix=".csv")

            open(path, "wb").write(content.encode())

            new_source = self.sources.static_file_upload(
                name=name,
                content=path,
                org_id=orgid
            )

            os.close(file_dir)

            if "sourceMetadata" in new_source:
                del new_source["sourceMetadata"]

            return new_source

        elif type == "generic":

            return self.sources.upload_big_dataset(
                name=name,
                org_id=orgid,
                content=content,
                encoding=encoding,
                chunks=chunks
            )

        else:
            raise Exception("Unsupported type of source to be imported")

    def export_source(self, org_id, dataset_ids):
        """
        method to retrieve the content of a dataset
        :param org_id: ORG id where the dataset is located
        :param dataset_ids: dataset id to be retrieved
        :return:
        """
        return self.sources.create_export_dataset(
            org_id=org_id,
            dataset_ids=dataset_ids
        )

    def append_data(self, content, orgid, dataset_id):
        """
        Method to append the given contento to the dataset id
        :param content: dataset comntent to be appended
        :param orgid: ORg id where the target dataset lives
        :param dataset_id:
        :return:
        """
        return self.sources.append_dataset(
            org_id=orgid,
            data_set_id=dataset_id,
            content=content
        )

    def dataset_list(self, org_id):
        """
        Retrieves all dataset metdata on the given org
        :param org_id: ORG id to be queried
        :return:
        """
        try:
            sources = self.sources.get_sources(org_id=org_id)

            for source in sources:
                if "fields" in source:
                    if "schema" in source["fields"]:
                        del source["fields"]["schema"]
            return sources
        except Exception as error:
            raise error

    def pipeline_list(self, org_id):
        """
        Retrieves all pipeline metdata on the given org
        :param org_id: ORG id to be queried
        :return:
        """
        try:
            sources = self.pipelines.get_pipelines_v2(org_id=org_id)

            return sources["pipelineSummaries"]

        except Exception as error:
            raise error

    def execute_query(self, query, orgid, format):
        """
        Executes the given sql query through asset access on the given og
        :param query:
        :param orgid:
        :param format:
        :return:
        """

        access = AssetAccess(cluster=self.cluster, orgid=orgid, props=self.properties)

        result = access.execute_query(query=query)

        if format == "csv":
            return json_to_csv(result, io_format=False)

        return result

    def assethub_access_tables(self, orgid):
        """
        Retrieves all the asset access tables on the given org
        :param orgid: ORG id to query the asset access tables
        :return:
        """
        access = AssetAccess(cluster=self.cluster, orgid=orgid, props=self.properties)

        return access.get_all_tables()

    def import_sources(self, org_id, pipeline_id, content, handleduplicates="clone", update_pipeline=True):
        """
        Method to import the sources, this method is used on the wf import pipelines
        :param org_id: ORG id where the sources are going to be imported
        :param pipeline_id: in case the sources that are imported and a pipeline used then
        :param content: Content file has all the data,
        normally generated from create_export_source_file
        :param handleduplicates: In case there is a dataset with the same name,
        this will add a uui at the end
        :param update_pipeline: Boolean value
        :return:
        """

        try:
            data = json.loads(content)

            non_evergreen_conversion_type = {
                "JsonPiConfigFileSourceMetaData": "piconfig",
                "JsonFileSourceMetadata": "external",
                "JsonPiWebApiSourceMetadata": "web",
                "PI_Upload": "piconfig",
                "Upload": "external",
                "api_dataset": "api_dataset",
                "PiWeb": "web"
            }

            needed_keys = {"id", "component", "schema", "type", "file_content", "name"}

            already_created_by_name = {}

            for source_to_import in data:

                if needed_keys.issubset(source_to_import.keys()):

                    which_type = None

                    if self.evergreen_enabled:

                        which_type = non_evergreen_conversion_type[source_to_import["type"]]

                        if which_type in ["external", "api_dataset"]:

                            file_dir, path = mkstemp(suffix=".csv")

                            open(path, "wb").write(
                                json_to_csv(
                                    source_to_import["file_content"],
                                    io_format=False
                                ).encode()
                            )

                            new_source = self.sources.static_file_upload(
                                name=source_to_import["name"],
                                content=path,
                                org_id=org_id
                            )

                            source_to_import["new_source_id"] = new_source["id"]

                            already_created_by_name[source_to_import["name"]] = new_source["id"]

                            os.close(file_dir)
                            try:
                                os.remove(path)
                            except OSError:
                                pass

                        if which_type in ["piconfig", "web"]:

                            file_dir, path = mkstemp(suffix=".csv")

                            server_name = remove_special(
                                out_file=path,
                                data_array=source_to_import["file_content"]
                            )

                            if server_name is None:
                                server_name = "PITAGCONFIGFILESERVER"

                            new_source = self.sources.pi_config_upload(
                                name=source_to_import["name"],
                                server_name=server_name,
                                file_path=path,
                                org_id=org_id
                            )

                            source_to_import["new_source_id"] = new_source["id"]

                            already_created_by_name[source_to_import["name"]] = new_source["id"]

                            os.close(file_dir)
                            try:
                                os.remove(path)
                            except OSError:
                                pass

                    else:
                        which_type = non_evergreen_conversion_type[source_to_import["type"]]

                        if source_to_import["name"] in already_created_by_name:

                            source_to_import["new_source_id"] = already_created_by_name[
                                source_to_import["name"]
                            ]

                        else:
                            if which_type in ["external", "web"]:

                                file_dir, path = mkstemp(suffix=".csv")

                                open(path, "wb").write(
                                    json_to_csv(
                                        source_to_import["file_content"],
                                        io_format=False
                                    ).encode()
                                )

                                new_source = self.sources.static_file_upload(
                                    name=source_to_import["name"],
                                    content=path,
                                    org_id=org_id
                                )

                                source_to_import["new_source_id"] = new_source["id"]

                                already_created_by_name[source_to_import["name"]] = new_source["id"]

                                os.close(file_dir)

                                try:
                                    os.remove(path)
                                except OSError:
                                    pass
                            if which_type == "piconfig":

                                file_dir, path = mkstemp(suffix=".csv")

                                server_name = remove_special(
                                    out_file=path,
                                    data_array=source_to_import["file_content"]
                                )

                                if server_name is None:
                                    server_name = "PITAGCONFIGFILESERVER"

                                new_source = self.sources.pi_config_upload(
                                    name=source_to_import["name"],
                                    server_name=server_name,
                                    file_path=path,
                                    org_id=org_id
                                )

                                source_to_import["new_source_id"] = new_source["id"]
                                already_created_by_name[source_to_import["name"]] = new_source["id"]

                                os.close(file_dir)

                                try:
                                    os.remove(path)
                                except OSError:
                                    pass



                else:
                    raise Exception("Missing export data {} ".format(
                        needed_keys.difference(source_to_import.keys()))
                    )

            if update_pipeline:

                pipeline_info = self.pipelines.get_pipeline(
                    org_id=org_id,
                    pipeline_id=pipeline_id
                )

                for component in pipeline_info["pipeline"]["data"]["components"]:

                    if component["jsonClass"] == "JsonSourceRef":

                        for modified_source in data:

                            if modified_source["component"] == component["id"]:
                                component["sourceId"] = modified_source["new_source_id"]

                self.pipelines.update_pipeline_from_json(
                    org_id=org_id,
                    update_payload=pipeline_info["pipeline"]["data"],
                    pipeline_id=pipeline_id,
                    pipeline_name=pipeline_info["pipeline"]["data"]["name"]
                )

                return json.dumps(pipeline_info)

            return "Data sets imported successfully"

        except Exception as error:
            raise error

    def use_existing_datasets(self, org_id, pipeline_id, content):
        """
        Method to use the existing datasets in the pipeline to be imported
        :param org_id: Destination org where datasets live
        :param pipeline_id: Pipelien which is being exported
        :param content:
        :return:
        """
        try:
            errors = set()
            pipeline_info = self.pipelines.get_pipeline(
                org_id=org_id,
                pipeline_id=pipeline_id
            )

            data = json.loads(content)

            sources = self.sources.get_sources(org_id=org_id)

            current_name_to_id = {}

            for source in sources:
                current_name_to_id[source["name"]] = source["id"]

            import_id_to_name = {}
            for source_to_import in data:
                import_id_to_name[source_to_import["id"]] = source_to_import["file_content"]

            for component in pipeline_info["pipeline"]["data"]["components"]:
                if component["jsonClass"] == "JsonSourceRef":

                    for modified_source in data:

                        if modified_source["component"] == component["id"]:
                            if import_id_to_name[component["sourceId"]] in current_name_to_id:

                                component["sourceId"] = current_name_to_id[
                                    import_id_to_name[component["sourceId"]]
                                ]

                            else:
                                errors.add(
                                    "No dataset with name {} was found".format(
                                        import_id_to_name[component["sourceId"]]
                                    )
                                )

                                component["sourceId"] = str(uuid.uuid4())

                self.pipelines.update_pipeline_from_json(
                    org_id=org_id,
                    update_payload=pipeline_info["pipeline"]["data"],
                    pipeline_id=pipeline_id,
                    pipeline_name=pipeline_info["pipeline"]["data"]["name"]
                )

        except Exception as err:
            raise err

        return list(errors)

    def create_export_source_file(self, org_id, pipeline_id, skip):
        """
        THis methods creates the export file
        :param org_id:
        :param pipeline_id:
        :param skip:
        :return:
        """

        sources = self.sources.get_sources(org_id=org_id)

        source_id_to_data = {}

        result_data = []

        for source in sources:
            if self.evergreen_enabled:
                source_id_to_data[source["id"]] = source
            else:
                source_id_to_data[source["id"]] = source

        pipeline_info = self.pipelines.get_pipeline(org_id=org_id, pipeline_id=pipeline_id)

        for component in pipeline_info["pipeline"]["data"]["components"]:
            if component["jsonClass"] == "JsonSourceRef":
                source_data = {
                    "id": component["sourceId"],
                    "component": component["id"]
                }

                if component["sourceId"] in source_id_to_data:

                    if self.evergreen_enabled:

                        source_data["schema"] = source_id_to_data[source_data["id"]]["fields"]["schema"]

                        source_data["name"] = source_id_to_data[source_data["id"]]["name"]

                        if "ean.source_type" in source_id_to_data[source_data["id"]]["fields"]:
                            source_data["type"] = source_id_to_data[source_data["id"]]["fields"]["ean.source_type"]
                        else:
                            source_data["type"] = "api_dataset"

                    else:
                        source_data["name"] = source_id_to_data[source_data["id"]]["name"]
                        source_data["schema"] = source_id_to_data[source_data["id"]]["schema"]
                        source_data["type"] = source_id_to_data[source_data["id"]]["sourceMetadata"]["jsonClass"]

                    if skip:
                        source_data["file_content"] = source_id_to_data[source_data["id"]]["name"]
                    else:
                        source_original_data = self.sources.download_dataset_content(
                            org_id=org_id,
                            dataset_id=component["sourceId"]
                        )
                        source_data["file_content"] = csv_to_json(csv_data=source_original_data)

                    result_data.append(source_data)

        return json.dumps(result_data)

    def create_pipeline_export_data(self, org_id, pipeline_id, skip):
        """
        Method to create all the necessary data to export a pipeline
        :param org_id: ORG id where the pipeline to be migrated is located
        :param pipeline_id: Pileine id to be exported
        :param skip: list of assets tp export, datasets and templates
        :return:
        """
        try:
            results = {}

            pipeline_info = self.pipelines.get_pipeline(org_id=org_id, pipeline_id=pipeline_id)

            templates_used = []
            aux_list = self.templates.list_asset_templates(org_id=org_id)

            mapped_templates = []

            results["map_attributes"] = {}

            for component in pipeline_info["pipeline"]["data"]["components"]:

                if component["jsonClass"] == "JsonMapTemplates":

                    for mapped_value in component["values"]:
                        mapped_templates.append(mapped_value[1])

                if component["jsonClass"] == "JsonMapAttributes":
                    results["map_attributes"][component["id"]] = csv_to_json(
                        csv_data=self.pipelines.download_map_attributes(
                            org_id=org_id,
                            pipeline_id=pipeline_id,
                            component_id=component["id"]
                        )
                    )

            used_templates = []
            template_id_to_name = {}
            for temp in aux_list:
                if str(temp["id"]) in mapped_templates:
                    used_templates.append(temp["id"])
                    template_id_to_name[str(temp["id"])] = temp["name"]
                    if "updatedBy" in temp:
                        del temp["updatedBy"]
                    if "updated" in temp:
                        del temp["updated"]
                    templates_used.append(temp)

            results["pipeline"] = pipeline_info

            results["sources"] = json.loads(
                self.create_export_source_file(
                    org_id=org_id,
                    pipeline_id=pipeline_id,
                    skip="datasets" in skip
                )
            )

            if "templates" in skip:

                results["pipeline"], _ = self.change_template_ids_to_names(
                    pipeline_data=results["pipeline"],
                    templates_data=template_id_to_name
                )

                results["templates"] = []

                results["template_values"] = []

            else:

                results["templates"] = templates_used

                results["template_values"] = json.loads(
                    self.templates.download_given_templates(
                        org_id=org_id,
                        template_list=used_templates,
                        format="json")
                )

            return json.dumps(results)

        except Exception as error:
            raise error

    def change_template_ids_to_names(self, pipeline_data, templates_data):
        """
        Method to change the templates ids to its name
        :param pipeline_data: Pipileine json blob where templates are used
        :param templates_data: Templates data to be used
        :return:
        """

        errors = set()

        for component in pipeline_data["pipeline"]["data"]["components"]:

            if component["jsonClass"] == "JsonMapTemplates":

                if "values" in component:
                    new_val = []
                    for value in component["values"]:
                        row_vale = value[0]
                        template_id = value[1]
                        if template_id in templates_data:
                            new_val.append(
                                [
                                    row_vale,
                                    templates_data[template_id]
                                ]
                            )
                        else:
                            errors.add("{} not found".format(row_vale))

                    component["values"] = new_val

        return pipeline_data, list(errors)

    def change_tempate_names_to_ids(self, pipeline_data, templates_data):
        """
        Method to change the templates names to its ids
        :param pipeline_data: Pipileine json blob where templates are used
        :param templates_data: Templates data to be used
        :return:
        """

        errors = set()

        for component in pipeline_data["pipeline"]["pipeline"]["data"]["components"]:

            if component["jsonClass"] == "JsonMapTemplates":

                if "values" in component:
                    new_val = []
                    for value in component["values"]:
                        row_vale = value[0]
                        template_name = value[1]
                        if template_name in templates_data:
                            new_val.append(
                                [
                                    row_vale,
                                    str(templates_data[template_name])
                                ]
                            )
                        else:
                            errors.add("{} not found".format(template_name))

                    component["values"] = new_val

        return pipeline_data, list(errors)

    def proceses_importing_pipeline_file(self, org_id, content, skip, handleduplicates="clone"):
        """
        Main method to process pipeline importing.
        :param org_id: target org id where the pipelien will be imported
        :param content: pipeline import content
        :param skip: variable to skip datasets or templates
        :param handleduplicates: Boolean variable to decide what to do with duplicate pipeline
        :return:
        """
        try:
            errors = []
            data = json.loads(content)

            if handleduplicates == "clone":

                temp_name = data["pipeline"]["pipeline"]["data"]["name"]

                if self.pipelines.pipeline_exists(org_id=org_id, pipeline_name=temp_name):
                    data["pipeline"]["pipeline"]["data"]["name"] = "{}_{}".format(
                        temp_name,
                        str(uuid.uuid4())[:5]
                    )

            if "pipeline" not in data:
                raise Exception("Pipeline data was not found")

            pipeline_info = data["pipeline"]

            if "templates" not in data:
                raise Exception("Template data was not found")

            if "template_values" not in data:
                raise Exception("Template definitions was not found")

            if len(data["template_values"]) > 0:
                try:

                    self.templates.upload_string_content_file(
                        content=json_to_csv(
                            data_array=data["template_values"],
                            io_format=False
                        ),
                        org_id=org_id
                    )

                except Exception as error:
                    errors.append("Exporting many templates can cause issues!")

            template_info = data["templates"]

            templates = self.templates.list_asset_templates(org_id=org_id)

            current_id_name_map = {}
            prev_id_name_map = {}

            for template in template_info:
                prev_id_name_map[str(template["id"])] = template["name"]

            for template in templates:
                current_id_name_map[template["name"]] = template["id"]

            if "templates" in skip:
                data, err = self.change_tempate_names_to_ids(
                    pipeline_data=data,
                    templates_data=current_id_name_map
                )

                errors.extend(err)

            attributes_name_to_id = {}

            data["map_recipes"] = {}

            for used_template in data["templates"]:

                current_temp_id = current_id_name_map[used_template["name"]]

                attrs = self.templates.get_attributes(
                    org_id=org_id,
                    teamplate_id=current_temp_id
                )

                attributes_name_to_id[current_temp_id] = {}

                for item in attrs["items"]:
                    attributes_name_to_id[current_temp_id][item["name"]] = item["id"]

            for component in pipeline_info["pipeline"]["data"]["components"]:

                if component["jsonClass"] == "JsonMapTemplates":
                    if "templates" not in skip:
                        for mapped_value in component["values"]:
                            mapped_value[1] = str(
                                current_id_name_map[prev_id_name_map[mapped_value[1]]]
                            )

                if component["jsonClass"] == "JsonMapAttributes":
                    data["map_recipes"][component["id"]] = data["map_attributes"][component["id"]]

            pipeline = self.pipelines.create_pipeline(
                org_id=org_id,
                name=data["pipeline"]["pipeline"]["data"]["name"]
            )

            created_pipeline_id = pipeline['pipeline']['id']

            self.pipelines.update_pipeline_from_json(
                org_id=org_id,
                update_payload=data["pipeline"]["pipeline"]["data"],
                pipeline_id=created_pipeline_id,
                pipeline_name=data["pipeline"]["pipeline"]["data"]["name"]
            )

            for component_id, recipe in data["map_recipes"].items():
                self.pipelines.upload_map_attributes_from_json(
                    org_id=org_id,
                    component_id=component_id,
                    pipeline_id=created_pipeline_id,
                    json_data=recipe
                )

            if "sources" in data:
                if "datasets" not in skip:
                    self.import_sources(
                        org_id=org_id,
                        pipeline_id=created_pipeline_id,
                        content=json.dumps(data["sources"]),
                        handleduplicates=handleduplicates,
                    )

                else:
                    err = self.use_existing_datasets(
                        org_id=org_id,
                        pipeline_id=created_pipeline_id,
                        content=json.dumps(data["sources"]),
                    )
                    errors.append(err)

            results = {
                "pipeline_id": created_pipeline_id,
                "org_id": org_id,
                "url": "{}#/org/{}/pipelines/{}".format(
                    self.properties.get_remote(self.cluster),
                    org_id,
                    created_pipeline_id
                ),
                "errors": errors
            }

            return json.dumps(results)
        except Exception as error:
            raise error
