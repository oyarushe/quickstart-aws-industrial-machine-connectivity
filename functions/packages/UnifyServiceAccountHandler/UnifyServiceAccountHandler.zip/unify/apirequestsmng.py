"""
This file has the general class to inherite from when creating a new api
client servcie
"""
import json
import requests

class ApiRequestManager:
    """
    Class blueprint to have general api request methods
    """

    def __init__(self, cluster, props):
        """
        Class constructire
        :param cluster: cluster name to interact with
        :param props: Instantiated Properties from unify/properties
        """
        self.props = props
        self.session = requests.Session()
        self.content_type_header = {"content-type": "application/json"}
        self.x_auth_token_header = "x-auth-token"
        self.x_org_header = "x-organization-id"
        self.cluster = cluster
        self.evergreen_enabled = True

    def close_session(self):
        """
        Method to close request session
        :return:
        """
        self.session.close()

    def verify_auth_token(self):
        """
        Method to verify if the auth token is set
        :return:
        """
        if self.props.get_auth_token() is None:
            raise Exception(
                "Authentication is required with remote server, login running ah login"
            )

    def verify_remote(self):
        """
        Verify if the remote cluster is se
        :return:
        """
        if self.props.get_remote() is None:
            raise Exception(
                "Remote server must be setup first"
            )

    def verify_properties(self):
        """
        Method to verify both auth token and remote cluster
        :return:
        """
        self.verify_auth_token()
        self.verify_remote()

    def auth_token(self):
        """
        Main method to authenticate with the given credentials
        :return:
        """

        username = self.props.get_username(cluster=self.cluster)
        password = self.props.get_password(cluster=self.cluster)

        try:
            data = {"email": username, "password": password}

            url = '{}api/sessions'.format(
                self.props.get_remote(cluster=self.cluster)
            )

            post_response = self.session.post(
                url,
                headers=self.content_type_header,
                data=json.dumps(data)
            )

            if post_response.status_code == 200:

                return json.loads(post_response.content)["authToken"]

            raise Exception(post_response.content)

        except Exception as error:

            raise error

    def build_header(self, aut_token=None, org_id=None, others=None):
        """
        Helper function to create request header
        :param aut_token: x-auth-toben to be included
        :param org_id: org id where the request will be aimed
        :param others: other headers to be included.
        :return:
        """
        header = dict()

        if others is not None and isinstance(others, dict):
            header.update(others)

        if aut_token is not None:
            header[self.x_auth_token_header] = aut_token

        if org_id is not None:
            header[self.x_org_header] = str(org_id)

        return header

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        pass
