"""
This class represents a cluster when stored on memory
"""


class Cluster:
    """
    Class to store cluster data on memory
    """

    def __init__(self, userName, password, cluster, token):
        """
        Cluster class constructor
        :param userName: cluster login username
        :param password: cluster login password
        :param cluster: cluster url, format http://host
        :param token: Auth token
        """
        self.userName = userName
        self.password = password
        self.cluster = cluster
        self.token = token

    def get_password(self):
        """
        Get cluster password
        :return:
        """
        return self.password

    def get_username(self):
        """
        Get cluster password
        :return:
        """
        return self.userName
