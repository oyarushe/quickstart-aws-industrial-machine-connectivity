"""
This file contains methods to interact with templates endpoints
"""
import json
import time
import os

from unify.properties import Properties
from unify.properties import ClusterSetting
from unify.apirequestsmng import ApiRequestManager
from unify.generalutils import csv_to_json


class Templates(ApiRequestManager):
    """
    Template client class to interact with templates endpoints
    """
    def __init__(self, cluster=None, props=Properties(ClusterSetting.KEY_RING)):
        """
        Class consturctor
        :param cluster: Cluster name ot interact with
        :param props: Instantiated Properties class
        """
        super().__init__(cluster=cluster, props=props)

        self.epoch_time = int(time.time())
        self.pi_tag_export_limit = {"piTagExportLimit": 999}
        self.expiry = {"expiry": 999}

        try:

            self.list_templates_uri = 'api/assetTemplates'

            self.upload_content_type_header = {"Content-Type": "multipart/form-data"}

            self.delete_content_type_header = {"Content-Type": "application/json"}

            self.upload_content_type = 'text/tab-separated-values'

            self.template_list_url = "api/template_management/v1/orgs/{}/templates"

            self.delete_template_uri = 'api/template_management/v1/templates/{}'

            self.root_templete_url = self.props.get_remote(
                self.cluster) + self.list_templates_uri

            self.upload_endpoint = self.props.get_remote(
                self.cluster) + 'api/template_management/v1/templates/upload'

            self.upload_parameters_endpoint = self.props.get_remote(
                self.cluster) + 'template_management/v1/orgs/{}/templates/metadata/upload'

            self.get_sensors_uri = self.root_templete_url + "/{}/sensors"

            self.template_download_url = self.props.get_remote(
                self.cluster) + "api/template_management/v1/templates/download"

            self.template_sensor_coverage_uri = self.props.get_remote(
                self.cluster) + "api/template_management/v1/templates/sensor-coverage"

            self.template_url = self.props.get_remote(
                self.cluster) + 'api/template_management/v1/templates'

            self.template_attribute = self.props.get_remote(
                self.cluster) + 'api/template_management/v1/orgs/{}/templates/{}/attributes'

            self.template_attribute_url = self.props.get_remote(
                self.cluster) + 'api/template_management/v1/orgs/{}/templates/{}/attributes/{}'

            self.categories_url = self.props.get_remote(
                self.cluster) + 'api/template_management/v1/orgs/{}/categories'

        except Exception as error:
            raise error

    def upload_template(self, file_path, org_id):
        """
        Upload the given file path with templates data
        :param file_path: file directory path with the templates contents
        :param org_id: Org id where templates are going to be saved
        :return:
        """

        if os.path.exists(file_path):
            file_upload = {'file': open(file_path, 'r+')}
        else:
            file_upload = {'file': file_path}

        upload_headers = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id
        )

        post_upload_template = self.session.post(
            self.upload_endpoint,
            headers=upload_headers,
            files=file_upload
        )

        if post_upload_template.status_code == 201:
            return json.loads(post_upload_template.content)

        raise Exception(post_upload_template.content)

    def get_attributes(self, org_id, teamplate_id):
        """
        Download all the attributes of the given template id
        :param org_id: Org where the templates are stored
        :param teamplate_id: Template id which attributes are being downloaded
        :return:
        """
        final_url = self.template_attribute.format(org_id, teamplate_id)

        upload_headers = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id
        )

        get_attrs = self.session.get(
            final_url,
            headers=upload_headers,
            params=[("pageSize", 2000)]
        )

        if get_attrs.status_code == 200:
            return json.loads(get_attrs.content)

        raise Exception(repr(get_attrs.content))

    def upload_string_content_file(self, org_id, content):
        """
        Upload templates data that are stored in the variable cotent
        :param org_id: Org id where templates are going to be stored
        :param content: Templates contents
        :return:
        """

        files = {'file': ('templates_uploads.csv', content, self.upload_content_type)}

        upload_headers = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id
        )

        post_upload_template = self.session.post(
            self.upload_endpoint,
            headers=upload_headers,
            files=files
        )

        if post_upload_template.status_code == 201:
            return json.loads(post_upload_template.content)

        raise Exception(post_upload_template.content)

    def upload_config(self, org_id, file_path):
        """
        Upload template metadata config file
        :param org_id: org where the config will be applied
        :param file_path: directory file path where the  contest are
        :param format: csv or tsv
        :return:
        """
        try:
            file_reader = open(file_path, "r+")
            content = file_reader.read()
        except FileNotFoundError:
            print('File does not exist')
        finally:
            file_reader.close()

        return self.upload_config_with_content(org_id, content)

    def upload_config_with_content(self, org_id, content, format="csv"):
        """
        Upload template configuration from content of a varibale and not a file
        :param org_id: org where the templates are stored
        :param content: template config content
        :param format: csv or tsv
        :return:
        """

        files = {
            'file': (
                f'templates_uploads.{format}',
                content,
                self.upload_content_type
            )
        }

        upload_headers = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id
        )

        post_upload_template = self.session.post(
            self.upload_parameters_endpoint.format(org_id),
            headers=upload_headers,
            files=files
        )

        if post_upload_template.status_code == 200:

            return json.loads(post_upload_template.content)

        raise Exception(post_upload_template.content)

    def _add_category(self, org_id, category):
        url = self.categories_url.format(org_id)
        headers = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id,
            others=self.content_type_header
        )
        payload = {
            "label": category,
        }

        request = self.session.post(
            url,
            headers=headers,
            data=json.dumps(payload),
        )
        if request.status_code == 200:
            return json.loads(request.content)
        raise Exception(request.content)

    def list_all_categories(self, org_id):
        """
        Retrieves all the template categories on the given org
        :param org_id: org id to be queried
        :return:
        """
        headers = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id,
        )
        request = self.session.get(
            self.categories_url.format(org_id),
            headers=headers
        )
        if request.status_code == 200:
            entries = json.loads(request.content)['entries']
            entries_dic = {}
            for entry in entries:
                label = entry['label']
                entries_dic.update({label: entry['id']})
            return entries_dic
        raise Exception(request.content)

    def category(self, org_id, template_id, template_name, version, categories):
        """
        update template categories
        :param org_id: org where the templates are stored
        :param template_id: template id
        :param template_name: template name
        :param version: template version
        :param categories: array contains the templates categories
        :return:
        """
        existing = self.list_all_categories(org_id)
        ids = []
        for cat in categories:
            if cat in existing:
                ids.append(existing.get(cat))
            else:
                i_d = self._add_category(org_id, cat)['id']
                ids.append(i_d)

        url = '{}/{}?version={}'.format(self.template_url, template_id, version)
        headers = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id,
            others=self.content_type_header
        )
        payload = {
            "organizationId": org_id,
            "name": template_name,
            "categoryIds": ids
        }

        request = self.session.put(
            url,
            headers=headers,
            data=json.dumps(payload),
            params=[("version", version)]
        )
        if request.status_code == 200:
            return json.loads(request.content)

        raise Exception(request.content)

    def get_template(self, org_id, template_id):
        """
        Retrives template by id
        :param org_id: org id of whom templates are being retrieved
        :param template_id: template id
        :return:
        """
        header = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id
        )
        url = self.template_url + '/' + str(template_id)
        request = self.session.get(url, headers=header)

        if request.status_code == 200:

            return json.loads(request.content)

        raise Exception(json.loads(request.content))

    def list_asset_templates(self, org_id):
        """
        Retrives the templates list from the given org
        :param org_id: org id of whom templates are being retrieved
        :return:
        """

        header = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id
        )

        list_request = self.session.get(self.root_templete_url, headers=header)

        if list_request.status_code == 200:

            return json.loads(list_request.content)["items"]

        raise Exception(json.loads(list_request.content))

    def download_template(self, org_id, list_templates=[]):
        """
        Download the templates data
        :param org_id: org where teh templates exists
        :param list_templates: array containing the templates list
        :return:
        """

        header = self.build_header(
            aut_token=self.props.get_auth_token(cluster=self.cluster),
            org_id=org_id,
            others=self.content_type_header
        )

        data = tuple(["templateId", name] for name in list_templates)

        get_response = self.session.get(self.template_download_url, headers=header, params=data)

        if get_response.status_code == 200:

            return get_response.content

        raise Exception(json.loads(get_response.content))

    def download_all_templates(self, org_id, format="csv"):
        """
        Retrieves all the templates data
        :param org_id: org where the templates are stored
        :param format: csv or json
        :return:
        """
        try:
            template_list_resp = self.list_asset_templates(org_id=org_id)

            template_list = [template["id"] for template in template_list_resp]

            data = self.download_template(org_id=org_id, list_templates=template_list)

            if format == "csv":
                return data

            return json.dumps(csv_to_json(csv_data=data))

        except Exception as error:
            raise error

    def download_given_templates(self, org_id, template_list, format="csv"):
        """
        Download the templates data
        :param org_id: org where teh templates exists
        :param template_list: array containing the templates list
        :param format: csv or json
        :return:
        """
        try:

            data = self.download_template(org_id=org_id, list_templates=template_list)

            if format == "csv":
                return data

            return json.dumps(csv_to_json(csv_data=data))

        except Exception as error:
            raise error
