import sys
import os
[sys.path.append(i) for i in ['.', '..']]

from unify_sitewise_model_sync.unify_sitewise_model_sync import ElementUnifySiteWiseModelSync

if __name__ == '__main__':
    agent = ElementUnifySiteWiseModelSync(
        username=os.environ.get('username'),
        password=os.environ.get('password'),
        orgId=22,
        hostname='https://app001-aws.elementanalytics.com/',
        region_name='us-west-2',
        bucket_name='imc-test005-workload-hkft8haj-elementunify-x0pqg17lwrua')
    agent.run()
