# Copyright 2021 Element Analytics, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Element Unify Handler, retrieves data model from Element Unify
"""
import logging
from collections import OrderedDict
from operator import getitem
import requests
from unify.sources import Sources
from unify.templates import Templates
from unify.properties import Properties, ClusterSetting
from unify.orgadmin import OrgAdmin
from helpers.helpers import lookup_list, get_dict_from_list_by_key, CaseInsensitiveDictReader

log = logging.getLogger('unifyHandler')
log.setLevel(logging.INFO)

class ElementUnifyHandler:
    """Retrieve and update Element Unify data model"""
    def __init__(self, appname, hostname):
        self.dataset_catalog_filter = ["AWS IoT SiteWise Model"]
        self.hostname = hostname
        self.appname = appname
        self.prop = Properties(ClusterSetting.MEMORY)
        self.headers = {}

        self.asset_templates = {}
        self.assets = {}
        self.asset_template_lookup_by_id = {}
        self.sources = None
        self.org = None
        self.org_id = ""

    def login(self, username, password):
        """Login"""
        self.prop.store_cluster(
            username=username,
            password=password,
            cluster=self.hostname,
            name=self.appname
        )
        self.org = OrgAdmin(
            cluster=self.appname,
            props=self.prop
        )
        self.prop.set_auth_token(
            token=self.org.auth_token(),
            cluster=self.appname
        )
        self.headers.update({"x-auth-token": self.prop.get_auth_token(self.appname)})
        self.sources = Sources(self.appname, self.prop)

    def select_org(self, org_id):
        """Select org"""
        self.org_id = org_id
        self.headers.update({'x-organization-id': self.org_id})

    def get_asset_templates_last_update(self):
        """Get last update timestamp for templates"""
        template_handler = Templates(self.appname, self.prop)
        templates = template_handler.list_asset_templates(self.org_id)
        template_dict = {
            template["name"]: {
                "uuid": template["uuid"],
                "updated": template["updated"]
            }
            for template in templates}
        return template_dict

    def list_asset_templates(self):
        """
        Retrieve asset templates from Element Unify
        """
        url = f'{self.hostname}api/template_management/v1/orgs/{self.org_id}/templates/batch'
        response = requests.get(url, headers=self.headers)

        if response.status_code not in [200, 201]:
            log.error("Could not retrieve asset templates from %s.", url)
            raise Exception(response.content)

        template_sets = response.json()["templates"]
        for template_set in template_sets:
            template_name = template_set["template"]["name"]

            if template_name not in self.asset_templates:
                self.asset_templates[template_name] = {
                    "assetModelProperties": {},
                    "assetModelHierarchies": [],
                    "assetModelName": template_name}

            for attribute in template_set["attributes"]:

                attribute_name = attribute["name"]

                unit = attribute["uom"] if "uom" in attribute else None

                property_type_value = lookup_list(attribute["metadataCollection"], "key", "Property Type", "value")
                attribute_type = {"measurement": {}} if property_type_value is None else {property_type_value.lower(): {}}

                default_value_param = lookup_list(attribute["metadataCollection"], "key", "Default Value", "value")
                default_value = default_value_param if default_value_param is not None and default_value_param != ""  else ""

                primitive_type = attribute["type"].get("primitiveType")
                if primitive_type is not None:
                    primitive_type = primitive_type.upper()

                template_attributes = self.asset_templates[template_name]["assetModelProperties"]
                if attribute_name not in template_attributes and primitive_type is not None:
                    if "measurement" in attribute_type:
                        template_attributes[attribute_name] = {
                            "name": attribute_name,
                            "dataType": primitive_type,
                            "type": {"measurement": {}}}
                        if unit is not None:
                            template_attributes[attribute_name].update({
                                "unit": unit})
                    elif "attribute" in attribute_type:
                        if default_value == "":
                            log.error("%s|%s is a static attribute, but missing required Default Value configuration parameter. Setting default value to null.", template_name, attribute_name)
                            default_value = "null"

                        template_attributes[attribute_name] = {
                            "name": attribute_name,
                            "dataType": primitive_type,
                            "type": {"attribute": {"defaultValue": default_value}}}

        self.store_recursive_template_associations(template_sets)

        return self.asset_templates

    def get_assets_dataset(self):
        """Get last update timestamp for datasets"""
        result = self.sources.get_sources_by_labels(self.org_id, self.dataset_catalog_filter)

        if result is None or len(result) == 0:
            log.error("Cannot retrieve assets dataset with label %s. No dataset found.", self.dataset_catalog_filter)
        elif len(result) > 1:
            log.warning("Two Element Unify datasets contain label %s. Only first dataset is used.", self.dataset_catalog_filter)

        if not(len(result) >= 1 and result[0].keys() >= {"id", "lastUpdatedAt", "lastSeqNum"}):
            return {
                "id": None,
                "lastUpdatedAt": None,
                "lastSeqNum": None}

        return {key: result[0][key] for key in result[0].keys() & {"id", "lastUpdatedAt", "lastSeqNum"}}

    def get_dataset_ids(self):
        """Get datasets"""
        return [dataset["id"] for dataset in self.sources.get_sources(org_id=self.org_id)]

    def list_assets(self):
        """
        Retrieve assets from Element Unify
        """
        result = self.get_assets_dataset()
        if result is None:
            return None

        content = self.sources.download_dataset_content(self.org_id, result["id"])
        content = str(content, "utf-8")

        reader = CaseInsensitiveDictReader(
            content.split('\n'),
            delimiter=",",
            quotechar='"')

        file_headers = reader.fieldnames
        required_headers = ["asset name", "asset model", "asset property", "asset path", "mapping"]
        header_delta = list(set(required_headers) - set(file_headers))
        if len(header_delta) > 0:
            raise Exception('Headers {} not found in dataset. Dataset must contain the headers: {}'
                .format(', '.join(header_delta), ', '.join(required_headers)))

        for row in reader:
            asset_name = row["asset name"]
            asset_template = row["asset model"]
            asset_attribute = row["asset property"] if row["asset property"] != "" else None
            parent_path = row["asset path"].lstrip("\\") if row["asset path"] != "None" else None
            parent_name = parent_path.split("\\")[-1] if parent_path is not None else None
            reference = row["mapping"] if row["mapping"] != "" else None
            full_path = f"{parent_path}\\{asset_name}" if parent_path is not None and parent_path != "" else asset_name
            level = len(full_path.split("\\"))
            if asset_name not in self.assets:
                self.assets[asset_name] = {
                    "name": asset_name,
                    "template": asset_template,
                    "attributes": [],
                    "parentPath": parent_path,
                    "parentName": parent_name,
                    "level": level
                    }

            if asset_attribute is not None:
                attribute_exists = get_dict_from_list_by_key(
                    list_dict=self.assets[asset_name]["attributes"],
                    dict_key="name",
                    match=asset_attribute) is not None
                if attribute_exists:
                    log.warning("Element Unify dataset contains duplicate alias mapping for %s|%s. Ignoring duplicates.", asset_name, asset_attribute)
                else:
                    self.assets[asset_name]["attributes"].append({
                        "name": asset_attribute,
                        "reference": reference})

        self.assets = OrderedDict(sorted(self.assets.items(), key = lambda x: getitem(x[1], 'level')))

        self.check_asset_path_recursive_template_integrity()

        return self.assets

    def store_recursive_template_associations(self, template_sets):
        """
        Build the recursive template associations based on hierarchy
        """
        # Template name lookup by uuid
        for template_set in template_sets:
            template_uuid = template_set["template"]["uuid"]
            template_name = template_set["template"]["name"]
            self.asset_template_lookup_by_id[template_uuid] = template_name

        # Store recursive templates
        for template_set in template_sets:
            template_name = template_set["template"]["name"]

            for attribute in template_set["attributes"]:
                contains_template_uuid = attribute["type"].get("templateUuid")
                contains_template_name = self.asset_template_lookup_by_id.get(contains_template_uuid)

                if contains_template_name is None:
                    continue

                elif get_dict_from_list_by_key(
                    list_dict=self.asset_templates[template_name]["assetModelHierarchies"],
                    dict_key="name",
                    match=contains_template_name) is None:
                    self.asset_templates[template_name]["assetModelHierarchies"].append({"name": contains_template_name})

    def check_asset_path_recursive_template_integrity(self):
        """
        Check that asset paths have associated recursive template definitions in Element Unify
        """
        for asset_definition in self.assets.values():
            child_template = asset_definition.get("template", "")
            parent_name = asset_definition.get("parentName", {})

            if asset_definition.get(parent_name) is None:
                continue

            parent_template = asset_definition.get(parent_name).get("template")
            if parent_template is None:
                continue
            
            if child_template not in self.asset_templates:
                log.error("Referenced template in asset dataset, %s, is not defined in Template Library", child_template)

            elif parent_template not in self.asset_templates:
                log.error("Referenced template in asset dataset, %s, is not defined in Template Library", parent_template)

    def update_dataset(self, content, dataset_name=None, dataset_id=None):
        """Update contents of dataset"""
        source = Sources(self.appname, self.prop)
        existing_datasets = [dataset["id"] for dataset in source.get_sources(org_id=self.org_id)]
        if dataset_id is None or dataset_id not in existing_datasets:
            response = source.create_api_data_set_with_content(
                name=dataset_name,
                org_id=self.org_id,
                content=content)
            dataset_id = response.get("data_set_id")
        else:
            source.truncate_data_set(
                org_id=self.org_id,
                data_set_id=dataset_id)

            source.append_dataset(
                org_id=self.org_id,
                data_set_id=dataset_id,
                content=content)

        return dataset_id
