# Copyright 2021 Element Analytics, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
SiteWise Handler, retrieves and updates AWS IoT SiteWise data model
"""

import time
import os
import json
import logging
from datetime import datetime
import calendar
import boto3
from botocore.exceptions import ClientError
from helpers.helpers import lookup_list, lookup_dict

log = logging.getLogger('sitewiseHandler')
log.setLevel(logging.INFO)

class SitewiseHandler:
    """Retrieve and update AWS IoT SiteWise data model"""

    def __init__(self, region):
        self.region = region
        self.sitewise = boto3.client('iotsitewise', region_name=self.region)
        self.refresh_interval = 0.5
        self.asset_models = {}
        self.assets = {}
        self.asset_properties = {}
        self.objects_to_delete = {"Asset Models": [], "Assets": [], "Asset Model Hierarchies": []}
        self.sitewise_tags = {"Managed by": "Element Unify"}

    # Retrieve Asset Models
    def list_asset_models(self):
        """
        Retrieve asset models
        """
        self.asset_models = {}

        paginator = self.sitewise.get_paginator("list_asset_models")
        page_iterator = paginator.paginate()

        for response in page_iterator:
            for model in response['assetModelSummaries']:
                resp = self.sitewise.describe_asset_model(assetModelId=model['id'])
                del resp['ResponseMetadata']
                model_name = resp["assetModelName"]
                self.asset_models[model_name] = resp
                self.asset_models[model_name]["assetModelProperties"] = \
                    {prop["name"]: prop for prop in self.asset_models[model_name]["assetModelProperties"]}

        return self.asset_models

    def wait_for_active_asset_model_status(self, asset_model_id):
        """
        Wait for asset model to be active

        :type assetModelId: str
        :param assetModelId: Asset model id
        """
        while True:
            model_description = self.sitewise.describe_asset_model(
                assetModelId=asset_model_id
            )
            if model_description['assetModelStatus']['state'] == 'ACTIVE':
                return model_description
            time.sleep(self.refresh_interval)

    def wait_for_active_asset_status(self, asset_id):
        """
        Wait for asset to be active

        :type asset_id: str
        :param asset_id: Asset id
        """
        while True:
            asset_description = self.sitewise.describe_asset(
                assetId=asset_id
            )
            if asset_description['assetStatus']['state'] == 'ACTIVE':
                return asset_description
            time.sleep(self.refresh_interval)

    def create_asset_model(self, asset_model_name, asset_model_properties=None, asset_model_hierarchies=None):
        """
        Create asset model

        :type asset_model_name: str
        :param asset_model_name: Asset model name
        :type asset_model_properties: dict
        :param asset_model_properties: Contains definition asset model properties
        :type asset_model_hierarchies: dict
        :param asset_model_hierarchies: Contains definition asset model hierarchies
        """
        log.info("Creating asset model %s", asset_model_name)
        if asset_model_properties is None:
            asset_model_properties = []

        if asset_model_hierarchies is None:
            asset_model_hierarchies = []

        try:
            model = self.sitewise.create_asset_model(
                assetModelName=asset_model_name,
                assetModelProperties=asset_model_properties,
                assetModelHierarchies=asset_model_hierarchies,
            )
        except ClientError as err:
            log.info("Exception: %s", err.response['Error']['Code'])

        response = self.wait_for_active_asset_model_status(asset_model_id=model['assetModelId'])

        self.tag_resource(resource_arn=response["assetModelArn"])

        return response

    def delete_asset_hierarchies_from_asset_model(self, asset_model_id):
        """
        Delete asset model hierarchy associations for given asset model

        :param asset_model_id: Asset model id
        :type asset_model_id: str
        """
        model = self.describe_asset_model(asset_model_id=asset_model_id)
        self.update_asset_model(
            asset_model_id=model["assetModelId"],
            asset_model_name=model["assetModelName"],
            asset_model_properties=model["assetModelProperties"],
            asset_model_hierarchies=[])

    def describe_asset_model(self, asset_model_id):
        """
        Describe asset model

        :type asset_model_id: str
        :param asset_model_id: Asset model id
        """
        try:
            return self.sitewise.describe_asset_model(assetModelId=asset_model_id)

        except self.sitewise.exceptions.ResourceNotFoundException:
            return None

    def describe_asset(self, asset_id):
        """
        Describe asset

        :type asset_id: str
        :param asset_id: Asset id
        """
        try:
            return self.sitewise.describe_asset(assetId=asset_id)

        except self.sitewise.exceptions.ResourceNotFoundException:
            return None

    def delete_asset(self, asset_id):
        """
        Delete asset

        :type asset_id: str
        :param asset_id: Asset id
        """
        log.info("Deleting asset %s", asset_id)

        try:
            self.sitewise.delete_asset(
                assetId=asset_id
            )
        except ClientError as err:
            log.info("Exception: %s", err.response['Error']['Code'])

    def update_asset_model(self, asset_model_id, asset_model_name, asset_model_properties, asset_model_hierarchies):
        """
        Update asset model properties and hierarchies

        :type asset_model_id: str
        :param asset_model_id: Asset name
        :type asset_model_name: str
        :param asset_model_name: Asset model name
        :type asset_model_properties: dict
        :param asset_model_properties: Asset model properties
        :type asset_model_hierarchies: dict
        :param asset_model_hierarchies: Asset model hierarchies
        """

        for prop_index in range(len(asset_model_properties)):
            asset_model_properties[prop_index].pop("diff", None)

        try:
            self.sitewise.update_asset_model(
                assetModelName=asset_model_name,
                assetModelId=asset_model_id,
                assetModelProperties=asset_model_properties,
                assetModelHierarchies=asset_model_hierarchies,
            )
        except ClientError as err:
            log.error("Exception: %s", err.response['Error']['Code'])
            log.error(json.dumps({
                "assetModelName": asset_model_name,
                "assetModelId": asset_model_id,
                "assetModelProperties": asset_model_properties,
                "assetModelHierarchies": asset_model_hierarchies,
            }, default=str))

        return self.wait_for_active_asset_model_status(asset_model_id=asset_model_id)

    def delete_asset_model(self, asset_model_id):
        """
        Delete asset model

        :type asset_model_id: str
        :param asset_model_id: Asset model id
        """
        log.info("Deleting asset model %s", asset_model_id)

        try:
            self.sitewise.delete_asset_model(
                assetModelId=asset_model_id
            )
        except ClientError as err:
            log.info("Exception: %s", err.response['Error']['Code'])

    def create_asset(self, asset_name, asset_model_id):
        """
        Create asset

        :type asset_name: str
        :param asset_name: Asset name
        :type asset_model_id: str
        :param asset_model_id: Asset model id
        """
        try:
            log.info("Creating asset %s", asset_name)
            asset = self.sitewise.create_asset(
                assetName=asset_name,
                assetModelId=asset_model_id
            )
        except ClientError as err:
            log.info("Exception: %s", err.response['Error']['Code'])

        response = self.wait_for_active_asset_status(asset['assetId'])

        self.tag_resource(resource_arn=response["assetArn"])

        return response

    def update_asset_property(self, asset_id, property_id, alias):
        """
        Update asset's property alias

        :type asset_id: str
        :param asset_id: Asset id
        :type property_id: str
        :param property_id: Property id
        :type alias: str
        :param alias: Property alias
        """
        try:
            log.info("Updating asset property %s|%s to %s", asset_id, property_id, alias)
            self.sitewise.update_asset_property(
                assetId=asset_id,
                propertyId=property_id,
                propertyNotificationState='ENABLED',
                propertyAlias=alias
            )
        except ClientError as err:
            log.info("Exception: %s", err.response['Error']['Code'])

    def batch_put_asset_property_value(self, asset_id, property_id, value):
        """
        Update asset's attribute property value

        :type asset_id: str
        :param asset_id: Asset id
        :type property_id: str
        :param property_id: Property id
        :type value: str
        :param value: value
        """
        try:
            log.info("Updating asset attribute property %s to %s", property_id, value)
            d = datetime.utcnow()
            current_time = calendar.timegm(d.utctimetuple())

            self.sitewise.batch_put_asset_property_value(
                entries=[
                    {
                        "assetId": asset_id,
                        "entryId": property_id,
                        "propertyId": property_id,
                        "propertyValues": [
                            {
                                "timestamp": {
                                    "timeInSeconds": current_time
                                },
                                "value": {
                                    "stringValue": value
                                }
                            }
                        ]
                    }
                ]
            )
        except ClientError as err:
            log.info("Exception: %s", err.response['Error']['Code'])

    def disassociate_asset(self, parent_asset_id, hierarchy_id, child_asset_id):
        """
        Diasassociate two assets

        :type parent_asset_id: str
        :param parent_asset_id: Parent asset id
        :type hierarchy_id: str
        :param hierarchy_id: Property id
        :type child_asset_id: str
        :param child_asset_id: Child asset id
        """
        try:
            log.info("Disassociating %s from %s", child_asset_id, parent_asset_id)
            self.sitewise.disassociate_assets(
                assetId=parent_asset_id,
                hierarchyId=hierarchy_id,
                childAssetId=child_asset_id,
            )
        except ClientError as err:
            log.info("Exception: %s", err.response['Error']['Code'])

    def associate_asset(self, parent_asset_id, hierarchy_id, child_asset_id):
        """
        Associate two assets

        :type parent_asset_id: str
        :param parent_asset_id: Parent asset id
        :type hierarchy_id: str
        :param hierarchy_id: Property id
        :type child_asset_id: str
        :param child_asset_id: Child asset id
        """
        try:
            log.info("Associating child %s to parent %s", child_asset_id, parent_asset_id)
            self.wait_for_active_asset_status(asset_id=parent_asset_id)
            self.wait_for_active_asset_status(asset_id=child_asset_id)
            self.sitewise.associate_assets(
                assetId=parent_asset_id,
                hierarchyId=hierarchy_id,
                childAssetId=child_asset_id,
            )
        except ClientError as err:
            log.info("Exception: %s", err.response['Error']['Code'])

    def list_assets(self):
        """
        Retrieve assets and compute parent information
        """
        self.assets={}
        for asset_model_name in self.asset_models.keys():

            paginator = self.sitewise.get_paginator("list_assets")
            page_iterator = paginator.paginate(
                assetModelId=self.asset_models[asset_model_name]["assetModelId"])

            for response in page_iterator:
                for asset in response['assetSummaries']:
                    asset = self.sitewise.describe_asset(assetId=asset['id'])
                    del asset["ResponseMetadata"]
                    asset_name = asset["assetName"]

                    asset["assetModelName"] = lookup_dict(
                        dictionary=self.asset_models,
                        key="assetModelId",
                        match=asset["assetModelId"],
                        return_key="assetModelName")

                    # get value for attribute properties
                    for prop in asset.get("assetProperties", []):
                        prop_id = prop["id"]

                        prop_type = self.get_property_type_from_asset_model_property(
                            asset_model=asset["assetModelName"],
                            property_name=prop["name"])

                        if prop_type == "attribute":
                            prop.update(
                                {"alias": self.get_asset_property_value(
                                    asset_id=asset["assetId"],
                                    property_id=prop_id)
                                })

                    self.assets[asset_name] = asset

        for asset in self.assets.values():

            # get associated assets
            paginator = self.sitewise.get_paginator("list_associated_assets")
            page_iterator = paginator.paginate(assetId=asset["assetId"], traversalDirection='PARENT')

            for response in page_iterator:
                for parent in response['assetSummaries']:
                    asset["parentName"] = parent["name"]
                    asset["parentId"] = parent["id"]
                    asset["parentHierarchyId"] = lookup_list(
                        list_obj=parent["hierarchies"],
                        key="name",
                        match=asset["assetModelName"],
                        return_key="id")

                if len(response['assetSummaries']) == 0:
                    asset["parentName"] = ""

        return self.assets

    def get_asset_property_value(self, asset_id, property_id):
        resp = self.sitewise.get_asset_property_value(
            assetId=asset_id,
            propertyId=property_id,
        )
        value_types = ["stringValue", "integerValue", "doubleValue", "booleanValue"]
        for value_type, actual_value in resp.get("propertyValue", {}).get("value", {}).items():
            if value_type in value_types:
                return str(actual_value)
        return ""

    def get_property_type_from_asset_model_property(self, asset_model, property_name):
        property_type_dict = self.asset_models\
                                .get(asset_model, {})\
                                .get("assetModelProperties", {})\
                                .get(property_name, {})\
                                .get("type")

        property_types = ["measurement", "attribute", "metric", "transform"]
        for property_type in property_types:
            if property_type in property_type_dict:
                return property_type
        return None

    def tag_resource(self, resource_arn):
        """
        Tag sitewise resources
        """
        response = self.sitewise.tag_resource(
            resourceArn=resource_arn,
            tags=self.sitewise_tags
        )
        return response
