""" Element Unify Model Sync, deploys and manages AWS IoT SiteWise
asset models and assets from Element Unify

Written by Element Analytics, Inc., 2021"""

import json
import os
import logging
import boto3
from botocore.exceptions import ClientError
from helpers.element_unify_handler import ElementUnifyHandler
from helpers.sitewise_handler import SitewiseHandler
from helpers.helpers import lookup_dict, lookup_list, get_dict_from_list_by_key

log = logging.getLogger('unifyModelSync')
log.setLevel(logging.DEBUG)

class ElementUnifySiteWiseModelSync:
    """Deploys and Manages updates to AWS IoT SiteWise

    It connects to the data models in Element Unify and AWS IoT SiteWise, computes the
    differences in the asset templates / asset models, and deploys or updates the
    AWS IoT SiteWise data model.
    """
    def __init__(self, username, password, orgId, hostname, region_name, bucket_name):
        self.appname = "unify"
        self.region_name = region_name
        self.s3 = boto3.resource('s3')
        self.last_update_s3_object = "elementUnifyLastUpdated.json"
        self.objects_to_delete_s3_object = "objectsToDelete.json"
        self.objects_to_delete_name="SiteWise - Objects to Delete"
        self.s3_bucket_name = bucket_name
        self.hostname = hostname
        self.org_id = str(orgId)
        self.username = username
        self.password = password
        self.element_unify_handler = None
        self.sitewise_handler = None
        self.secret_name = None
        self.content_objects_to_delete = ""

    def run(self):
        """Runs the model sync
        """
        self.element_unify_handler = ElementUnifyHandler(
            appname=self.appname,
            hostname=self.hostname)
        log.info("Connecting to hostname: %s and org: %s with %s", self.hostname, self.org_id, self.username)
        self.element_unify_handler.login(
            username=self.username,
            password=self.password)
        self.element_unify_handler.select_org(
            org_id=self.org_id)

        timestamp_check = False
        if timestamp_check and not self.is_model_updated(
            asset_templates=self.element_unify_handler.get_asset_templates_last_update(),
            asset_dataset=self.element_unify_handler.get_assets_dataset()):
            return

        # Connect to AWS IoT SiteWise
        self.sitewise_handler = SitewiseHandler(region=self.region_name)

        # Compare and update asset models/templates
        log.info("Retrieving Element Unify Asset Templates")
        self.element_unify_handler.list_asset_templates()

        log.info("Retrieving SiteWise Asset Models")
        self.sitewise_handler.list_asset_models()

        # Compute data model differences
        log.info("Computing asset model deltas")
        self.compute_delta_asset_templates(
            sitewise_models=self.sitewise_handler.asset_models,
            unify_templates=self.element_unify_handler.asset_templates)
        
        # Merge
        log.info("Merging Element Unify data model into SiteWise")
        self.create_update_sitewise_asset_models(
            sitewise_models=self.sitewise_handler.asset_models,
            unify_templates=self.element_unify_handler.asset_templates)

        # Handle assets
        log.info("Retrieving Element Unify Assets")
        self.element_unify_handler.list_assets()

        log.info("Retrieving SiteWise Assets")
        self.sitewise_handler.list_assets()

        log.info("Computing asset deltas")
        self.compute_delta_assets(
            sitewise_assets=self.sitewise_handler.assets,
            unify_assets=self.element_unify_handler.assets)

        # Create and merge data model
        log.info("Merging Element Unify data model into SiteWise")
        self.create_update_sitewise_assets(
            sitewise_assets=self.sitewise_handler.assets,
            unify_assets=self.element_unify_handler.assets)

        # Report on sw asset models and assets to delete
        log.info("Storing objects to delete")
        self.update_element_unify_logs(self.sitewise_handler.objects_to_delete)

    def compute_delta_asset_templates(self, sitewise_models, unify_templates):
        """
        Compute the delta between Element Unify and SiteWise asset templates or
        models. Assigns the key "diff" for deltas. "diff" values is below:
            -1: object to delete from SiteWise
            1: object to add from Element Unify
            2: object to update from Element Unify

        :type sitewise_models: dict
        :param sitewise_models: Contains definition of the AWS IoT SiteWise
            asset models, model hierarchies, and properties.
        :type unify_templates: dict
        :param unify_templates: Contains definition of the Element Unify
            asset templates, recursive relationships, and attributes templates.
        """

        all_asset_model_names = set(list(sitewise_models.keys()) + list(unify_templates.keys()))
        for model_name in all_asset_model_names:
            # Mark sitewise asset models to delete
            if model_name in sitewise_models and model_name not in unify_templates:
                log.info('SiteWise %s is not in Unify', model_name)
                sitewise_models[model_name].update({"diff": -1})
                self.sitewise_handler.objects_to_delete["Asset Models"].append(model_name)

            # Mark unify asset templates to create
            elif model_name not in sitewise_models and model_name in unify_templates:
                log.info('SiteWise does not contain %s', model_name)
                unify_templates[model_name].update({"diff": 1})

            # Traverse properties / attributes
            elif model_name in sitewise_models and model_name in unify_templates:
                sitewise_props = sitewise_models[model_name]["assetModelProperties"]
                unify_temp_attrs = unify_templates[model_name]["assetModelProperties"]
                all_asset_model_property_names = set(
                    list(sitewise_props.keys()) +
                    list(unify_temp_attrs.keys()))

                for prop_name in all_asset_model_property_names:

                    # Mark sitewise asset model properties to delete
                    if prop_name not in unify_temp_attrs:
                        log.info('SiteWise %s|%s is not in Unify', model_name, prop_name)
                        sitewise_props[prop_name].update({"diff": -1})
                        self.sitewise_handler \
                            .objects_to_delete["Asset Models"] \
                            .append(f"{model_name}|{prop_name}")

                    # Mark unify asset template attributes to create
                    elif prop_name not in sitewise_props:
                        log.info('SiteWise does not contain %s|%s', model_name, prop_name)
                        unify_temp_attrs[prop_name].update({"diff": 1})

                    # Mark properties that are different in Element Unify and SiteWise
                    elif "measurement" in unify_temp_attrs[prop_name]["type"]:
                        if "measurement" not in sitewise_props[prop_name]["type"]:
                            log.info("SiteWise %s|%s type is %s, but Unify\'s is measurement",
                                model_name,
                                prop_name,
                                sitewise_props[prop_name]["type"].get("type"))
                            unify_temp_attrs[prop_name].update({"diff": 2})
                        elif sitewise_props[prop_name].get("dataType") != unify_temp_attrs[prop_name].get("dataType"):
                            log.info("SiteWise %s|%s dataType is %s, but Unify\'s is %s",
                                model_name,
                                prop_name,
                                sitewise_props[prop_name].get("dataType"),
                                unify_temp_attrs[prop_name].get("dataType"))
                            unify_temp_attrs[prop_name].update({"diff": 2})
                        elif sitewise_props[prop_name].get("unit") != unify_temp_attrs[prop_name].get("unit"):
                            log.info("SiteWise %s|%s dataType is %s, but Unify\'s is %s",
                                model_name,
                                prop_name,
                                sitewise_props[prop_name].get("unit"),
                                unify_temp_attrs[prop_name].get("unit"))
                            unify_temp_attrs[prop_name].update({"diff": 2})

                    elif "attribute" in unify_temp_attrs[prop_name]["type"]:
                        if "attribute" not in sitewise_props[prop_name]["type"]:
                            log.info("SiteWise %s|%s type is %s, but Unify\'s is attribute",
                                model_name,
                                prop_name,
                                sitewise_props[prop_name]["type"].get("type"))
                            unify_temp_attrs[prop_name].update({"diff": 2})
                        elif sitewise_props[prop_name].get("dataType") \
                            != unify_temp_attrs[prop_name].get("dataType"):
                            log.info("SiteWise %s|%s dataType is %s, but Unify\'s is %s",
                                model_name,
                                prop_name,
                                sitewise_props[prop_name].get("dataType"),
                                unify_temp_attrs[prop_name].get("dataType"))
                            unify_temp_attrs[prop_name].update({"diff": 2})
                        elif sitewise_props[prop_name]["type"]["attribute"].get("defaultValue") \
                            != unify_temp_attrs[prop_name]["type"]["attribute"].get("defaultValue"):
                            log.info("SiteWise %s|%s defaultValue is %s, but Unify\'s is %s",
                                model_name,
                                prop_name,
                                sitewise_props[prop_name]["type"]["attribute"].get("defaultValue"),
                                unify_temp_attrs[prop_name]["type"]["attribute"].get("defaultValue"))
                            unify_temp_attrs[prop_name].update({"diff": 2})

            # Traverse recursive relationships
            unify_asset_model_hierarchies = set(
                assoc["name"]
                for assoc in unify_templates.get(model_name, {}).get("assetModelHierarchies", [])
            )
            sitewise_asset_model_hierarchies = set(
                assoc["name"]
                for assoc in sitewise_models.get(model_name, {}).get("assetModelHierarchies", [])
            )
            sitewise_model_hierarchy_delta = \
                sitewise_asset_model_hierarchies - unify_asset_model_hierarchies
            unify_model_hierarchy_delta = \
                unify_asset_model_hierarchies - sitewise_asset_model_hierarchies

            # Mark recursive templates to delete in sitewise
            for asset_hierarchy_name in sitewise_model_hierarchy_delta:
                asset_hierarchy_obj = get_dict_from_list_by_key(
                    list_dict=sitewise_models.get(model_name, {}).get("assetModelHierarchies", []),
                    dict_key="name",
                    match=asset_hierarchy_name
                )
                asset_hierarchy_obj.update({"diff": -1})
                self.sitewise_handler\
                    .objects_to_delete["Asset Model Hierarchies"]\
                    .append(f"{model_name}->{asset_hierarchy_name}")

            # Mark recursive templates to add from element unify
            for asset_hierarchy_name in unify_model_hierarchy_delta:
                asset_hierarchy_obj = get_dict_from_list_by_key(
                    list_dict=unify_templates.get(model_name, {}).get("assetModelHierarchies", []),
                    dict_key="name",
                    match=asset_hierarchy_name
                )
                asset_hierarchy_obj.update({"diff": 1})

    def create_update_sitewise_asset_models(self, sitewise_models, unify_templates):
        """
        Creates or updates AWS IoT SiteWise asset models, model hierarchies, and their properties

        :type sitewise_models: dict
        :param sitewise_models: Contains definition of the AWS IoT SiteWise
            asset models and properties.
        :type unify_templates: dict
        :param unify_templates: Contains definition of the Element Unify
            asset templates and attributes.
        """
        log.info("Creating or updating asset models")
        # Create any asset models first
        for asset_template_name, asset_template in unify_templates.items():

            if unify_templates[asset_template_name].get("diff") == 1:

                asset_model_properties = []
                for attr_temp_name, attr_temp in asset_template["assetModelProperties"].items():
                    asset_model_properties.append(attr_temp)

                response = self.sitewise_handler.create_asset_model(
                    asset_model_name=asset_template_name,
                    asset_model_properties=asset_model_properties
                )
                resp = self.sitewise_handler.wait_for_active_asset_model_status(asset_model_id=response['assetModelId'])
                log.info("Created asset model %s", asset_template_name)
                sitewise_models.update({asset_template_name: resp})

        # Update any existing asset properties
        for asset_template_name, asset_template in unify_templates.items():
            asset_model_id = sitewise_models[asset_template_name]["assetModelId"]
            asset_model = self.sitewise_handler.describe_asset_model(asset_model_id=asset_model_id)
            asset_model_properties = asset_model["assetModelProperties"]
            asset_model_hierarchies = asset_model["assetModelHierarchies"]

            model_is_different = False
            added_new_hierarchies = False
            # Update asset model hierarchies
            for asset_model_hierarchy in asset_template["assetModelHierarchies"]:
                child_model_name = asset_model_hierarchy["name"]
                child_model_id = sitewise_models.get(child_model_name).get("assetModelId")

                # check if the model already exists
                model_hierarchy_exists = get_dict_from_list_by_key(
                    list_dict=self.sitewise_handler.asset_models.get(asset_template_name, {}).get("assetModelHierarchies", []),
                    dict_key="name",
                    match=child_model_name) is not None
                 
                if not model_hierarchy_exists:
                    asset_model_hierarchies.append(
                        {"name": child_model_name, "childAssetModelId": child_model_id})
                    added_new_hierarchies = True

            for attr_temp_name, attr_temp in asset_template["assetModelProperties"].items():
                # Create new property if the property does not exist
                if attr_temp.get("diff") == 1:
                    asset_model_properties.append(attr_temp)
                    model_is_different = True

                # Update existing property
                elif attr_temp.get("diff") == 2:
                    asset_model_property = get_dict_from_list_by_key(
                        list_dict=asset_model_properties,
                        dict_key="name",
                        match=attr_temp_name)
                    asset_model_property.update({
                        "dataType": attr_temp["dataType"],
                        "type": attr_temp["type"]})

                    if "measurement" in attr_temp["type"] and "unit" in attr_temp:
                        asset_model_property.update({"unit": attr_temp["unit"]})
                        if "defaultValue" in asset_model_property:
                            del asset_model_property["defaultValue"]

                    elif "attribute" in attr_temp["type"] and "defaultValue" in attr_temp:
                        asset_model_property.update({"defaultValue": attr_temp["defaultValue"]})
                        if "unit" in asset_model_property:
                            del asset_model_property["unit"]

                    model_is_different = True

            if model_is_different or added_new_hierarchies:
                log.info("Updating asset model %s", asset_template_name)
                response = self.sitewise_handler.update_asset_model(
                    asset_model_id = asset_model_id,
                    asset_model_name = asset_template_name,
                    asset_model_properties = asset_model_properties,
                    asset_model_hierarchies = asset_model_hierarchies
                )
                resp = self.sitewise_handler.wait_for_active_asset_model_status(
                    asset_model_id=response['assetModelId'])

            # retrieve new asset models with hierarchy ids
            if added_new_hierarchies:
                self.sitewise_handler.list_asset_models()

    def compute_delta_assets(self, sitewise_assets, unify_assets):
        """
        Compute the delta between Element Unify and SiteWise assets.
        Assigns the key "diff" for deltas. "diff" values is below:
            -1: object to delete from SiteWise
            1: object to add from Element Unify
            2: object to update from Element Unify

        :type sitewise_assets: dict
        :param sitewise_assets: Contains definition of the AWS IoT SiteWise
            assets and properties.
        :type unify_assets: dict
        :param unify_assets: Contains definition of the Element Unify
            assets and attributes.
        """
        log.info("Computing asset delta")
        asset_names = set(list(sitewise_assets.keys()) + [asset["name"] for asset in unify_assets.values()])

        for asset_name in asset_names:

            # Mark SiteWise assets to delete
            if asset_name in sitewise_assets and asset_name not in unify_assets:
                sitewise_assets[asset_name].update({"diff": -1})
                self.sitewise_handler.objects_to_delete["Assets"].append(asset_name)

            # Flag the assets to be disassociated
            elif asset_name in sitewise_assets and asset_name in unify_assets and \
                unify_assets[asset_name]["parentName"] != sitewise_assets[asset_name]["parentName"]:

                sitewise_assets[asset_name].update(
                    {"rearrange": 1})
                sitewise_assets[asset_name].update(
                    {"parentNameNew": unify_assets[asset_name]["parentName"]})

            # Mark Element Unify assets to create
            elif asset_name not in sitewise_assets and asset_name in unify_assets:
                unify_assets[asset_name].update({"diff": 1})

            # Check properties that need to be updated
            if asset_name in sitewise_assets and asset_name in unify_assets:
                sitewise_asset_properties = sitewise_assets[asset_name]["assetProperties"]
                unify_asset_attributes = unify_assets[asset_name]["attributes"]

                for unify_attribute in unify_asset_attributes:
                    attribute_name = unify_attribute["name"]
                    sitewise_property = get_dict_from_list_by_key(
                        list_dict=sitewise_asset_properties,
                        dict_key="name",
                        match=attribute_name)

                    if sitewise_property is not None\
                        and sitewise_property.get("alias") != unify_attribute["reference"]:
                        sitewise_property.update({"diff": 1})
                        sitewise_property.update({"aliasNew": unify_attribute["reference"]})

    def create_update_sitewise_assets(self, sitewise_assets, unify_assets):
        """
        Creates or updates AWS IoT SiteWise assets, properties, and hierarchy:
            1) Disassociates assets that are in outdated hierarchy location
            2) Create new assets
            3) Update properties
            4) Associate assets to new hierarchy locations

        :type sitewise_assets: dict
        :param sitewise_assets: Contains definition of the AWS IoT SiteWise
            asset and properties.
        :type unify_assets: dict
        :param unify_assets: Contains definition of the Element Unify
            assets and attributes.
        """
        log.info("Creating or updating assets")
        # Disassociate assets to rearrange
        sitewise_asset_names = sitewise_assets.keys()
        for asset_name in sitewise_asset_names:
            if sitewise_assets[asset_name].get("rearrange") == 1 and \
                "parentId" in sitewise_assets[asset_name] and \
                "parentHierarchyId" in sitewise_assets[asset_name]:
                self.sitewise_handler.disassociate_asset(
                    parent_asset_id=sitewise_assets[asset_name]["parentId"],
                    hierarchy_id=sitewise_assets[asset_name]["parentHierarchyId"],
                    child_asset_id=sitewise_assets[asset_name]["assetId"])

        # Create assets and update asset properties
        unify_asset_names = [asset["name"] for asset in unify_assets.values()]
        for asset_name in unify_asset_names:

            # Create new assets
            if unify_assets[asset_name].get("diff") == 1:
                unify_asset_template_name = unify_assets[asset_name]["template"]
                unify_parent_asset_name = unify_assets[asset_name]["parentName"]
                asset_model_id = self.sitewise_handler.asset_models.get(unify_asset_template_name, {}).get("assetModelId")
                if asset_model_id is None:
                    raise Exception(f"SiteWise does not contain asset model {unify_asset_template_name}. Check that Unify contains an asset template {unify_asset_template_name}. Then re-run.")
                asset_new = self.sitewise_handler.create_asset(
                    asset_name=asset_name,
                    asset_model_id=asset_model_id)
                asset_new["isNewAsset"] = 1
                asset_new["rearrange"] = 1
                asset_new["parentNameNew"] = unify_parent_asset_name
                asset_new["assetModelName"] = lookup_dict(
                    dictionary=self.sitewise_handler.asset_models,
                    key="assetModelId",
                    match=asset_model_id,
                    return_key="assetModelName")
                sitewise_assets.update({asset_name: asset_new})

            # Update properties
            if asset_name in sitewise_assets:
                sitewise_asset = sitewise_assets[asset_name]
                unify_asset = unify_assets[asset_name]

                for sitewise_asset_property in sitewise_asset["assetProperties"]:

                    property_type = self.get_property_type_from_asset_property(
                        asset_name=asset_name,
                        property_name=sitewise_asset_property.get("name"))

                    unify_attribute = get_dict_from_list_by_key(
                            list_dict=unify_asset["attributes"],
                            dict_key="name",
                            match=sitewise_asset_property["name"]) 

                    # For existing assets, update any aliases
                    if sitewise_asset_property.get("diff") == 1:
                        if property_type == "measurement":
                            self.sitewise_handler.update_asset_property(
                                asset_id=sitewise_asset["assetId"],
                                property_id=sitewise_asset_property["id"],
                                alias=sitewise_asset_property["aliasNew"])
                        elif property_type == "attribute":
                            self.sitewise_handler.batch_put_asset_property_value(
                                asset_id=sitewise_asset["assetId"],
                                property_id=sitewise_asset_property["id"],
                                value=sitewise_asset_property["aliasNew"])
                    # For new assets, update aliases
                    elif sitewise_asset.get("isNewAsset") == 1 and \
                        unify_attribute is not None:
    
                        unify_asset_property_alias = \
                            unify_attribute.get("reference", "")

                        if property_type == "measurement":
                            self.sitewise_handler.update_asset_property(
                                asset_id=sitewise_asset["assetId"],
                                property_id=sitewise_asset_property["id"],
                                alias=unify_asset_property_alias)
                        elif property_type == "attribute":
                            self.sitewise_handler.batch_put_asset_property_value(
                                asset_id=sitewise_asset["assetId"],
                                property_id=sitewise_asset_property["id"],
                                value=unify_asset_property_alias)

        # Associate assets
        sitewise_asset_names = sitewise_assets.keys()
        for asset_name in sitewise_asset_names:
            if sitewise_assets[asset_name].get("rearrange") == 1 or \
                sitewise_assets[asset_name].get("isNewAsset") == 1:

                parent_name = sitewise_assets[asset_name]["parentNameNew"]
                if parent_name == "":
                    continue
                parent_asset_id = sitewise_assets[parent_name]["assetId"]
                parent_model_name = sitewise_assets[parent_name]["assetModelName"]
                child_asset_id = sitewise_assets[asset_name]["assetId"]
                child_model_name = sitewise_assets[asset_name]["assetModelName"]
                hierarchy_id = lookup_list(
                    list_obj=self.sitewise_handler.asset_models[parent_model_name]["assetModelHierarchies"],
                    key="name",
                    match=child_model_name,
                    return_key="id")

                self.sitewise_handler.associate_asset(
                    parent_asset_id=parent_asset_id,
                    hierarchy_id=hierarchy_id,
                    child_asset_id=child_asset_id)

    def get_property_type_from_asset_property(self, asset_name, property_name):
        """
        Retrieve property type for asset and property

        :param asset_name: Name of asset
        :type asset_name: str
        :param property_name: Name of property
        :type property_name: str
        """
        template_name = self.element_unify_handler.assets.get(asset_name, {}).get("template")
        property_type_dict = self.element_unify_handler.asset_templates\
                                .get(template_name, {})\
                                .get("assetModelProperties", {})\
                                .get(property_name, {})\
                                .get("type")

        if property_type_dict is None:
            return "measurement"

        property_types = ["measurement", "attribute", "metric", "transform"]
        for property_type in property_types:
            if property_type in property_type_dict:
                return property_type
        return None

    def update_element_unify_logs(self, objects_to_delete):
        """
        Store objects to delete as a dataset

        :type objects_to_delete: dict
        :param objects_to_delete: Contains definition of the AWS IoT SiteWise
            asset models and properties.
        """
        header = ["Model", "Type", "Name"]

        content_array = [header]
        for obj_type, obj_values in objects_to_delete.items():
            for obj_value in obj_values:
                content_array.append(["SiteWise", obj_type, obj_value])

        self.content_objects_to_delete = ""
        for row in content_array:
            self.content_objects_to_delete = self.content_objects_to_delete + ",".join(row) + "\n"
        if len(content_array) == 1:
            self.content_objects_to_delete = self.content_objects_to_delete + ",".join(["No differences", "No differences", "No differences"]) + "\n"

        dataset_id = self.read_from_s3(self.objects_to_delete_s3_object).get("dataset_id")
        dataset_ids = self.element_unify_handler.get_dataset_ids()

        if dataset_id is None or dataset_id not in dataset_ids:
            dataset_id = self.element_unify_handler.update_dataset(
                content=self.content_objects_to_delete,
                dataset_name = self.objects_to_delete_name)
            self.write_to_s3({'dataset_id': dataset_id}, self.objects_to_delete_s3_object)
        else:
            self.element_unify_handler.update_dataset(
                content=self.content_objects_to_delete,
                dataset_name = self.objects_to_delete_name,
                dataset_id=dataset_id)

    def is_model_updated(self, asset_templates, asset_dataset):
        """
        Returns whether or not the asset models or datasets have recently been updated

        :type asset_templates: dict
        :param asset_templates: Contains definition of asset templates
        : type asset_dataset: dict
        :param asset_dataset: Contains definition of datasets
        """
        if asset_dataset is None or asset_templates is None:
            return False

        model_last_updated = {
            "assetTemplates": asset_templates,
            "assetDataset": asset_dataset
        }
        prev_model_last_updated = self.read_from_s3(self.last_update_s3_object)

        if prev_model_last_updated.keys() < {"assetDataset", "assetTemplates"} or \
            model_last_updated["assetTemplates"].keys() != prev_model_last_updated["assetTemplates"].keys() or \
            model_last_updated["assetTemplates"] != prev_model_last_updated["assetTemplates"] or \
            model_last_updated["assetDataset"] != prev_model_last_updated["assetDataset"]:
            self.write_to_s3(model_last_updated, self.last_update_s3_object)
            log.info("Element Unify data model changed")
            return True

        log.info("Element Unify data model did not change")
        return False

    def read_from_s3(self, object_name):
        """
        Read object as dict from s3

        :type object_name: str
        :param object_name: object
        """
        try:
            log.info("Reading %s from %s.", object_name, self.s3_bucket_name)
            content = self.s3.Object(self.s3_bucket_name, object_name).get()['Body'].read()
            if content is None or content == "":
                return {}
            return json.loads(content)
        except ClientError as err:
            log.error("Failed reading from bucket: %s, object: %s, error: %s", self.s3_bucket_name, object_name, err.response['Error']['Code'])
            return {}

    def write_to_s3(self, dictionary, object_name):
        """
        Returns whether or not the asset models or datasets have recently been updated

        :type dictionary: dict
        :param dictionary: Contains dictionary to write to s3 object
        :type object_name: str
        :param object_name: Name of object
        """
        s3_object = self.s3.Object(self.s3_bucket_name, object_name)
        s3_object.put(Body=json.dumps(dictionary, indent=2, default=str))
