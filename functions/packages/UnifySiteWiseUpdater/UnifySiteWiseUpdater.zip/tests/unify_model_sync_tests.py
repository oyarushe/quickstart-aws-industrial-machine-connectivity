import unittest
import json
import os
from unify_model_sync.unify_model_sync import ElementUnifySiteWiseModelSync
from helpers.element_unify_handler import ElementUnifyHandler
from helpers.sitewise_handler import SitewiseHandler
from helpers.helpers import get_element_unify_secrets

def get_dict(filename):
    with open(filename, "r") as f:
        contents = f.read()
        try:
            return json.loads(contents)
        except:
            return {}

def get_dict_str(dict):
    return json.dumps(dict, indent=2, default=str)

class ElementUnifyModelSyncTest(unittest.TestCase):

    def test_compute_delta_templates(self):
        username = os.environ.get('username')
        password = os.environ.get('password')
        org_id = os.environ.get('orgId')
        hostname = os.environ.get('hostname')
        model_sync = ElementUnifySiteWiseModelSync(username, password, org_id, hostname)
        model_sync.element_unify_client = ElementUnifyHandler(
            appname=None,
            hostname=None)
        model_sync.sitewise_handler = SitewiseHandler()

        model_sync.element_unify_client.asset_templates = get_dict("test/data/diff_unify_templates.json")
        model_sync.element_unify_client.assets = get_dict("test/data/diff_unify_assets.json")
        model_sync.sitewise_handler.asset_models = get_dict("test/data/diff_sitewise_asset_models.json")
        model_sync.sitewise_handler.assets = get_dict("test/data/diff_sitewise_assets.json")

        model_sync.compute_delta_asset_templates(
            sitewise_models=model_sync.sitewise_handler.asset_models,
            unify_templates=model_sync.element_unify_client.asset_templates)
        model_sync.compute_delta_assets(
            sitewise_assets=model_sync.sitewise_handler.assets,
            unify_assets=model_sync.element_unify_client.assets)

        self.assertEqual(
            model_sync.element_unify_client.asset_templates,
            get_dict("test/data/diff_unify_templates_computed.json"))
        self.assertEqual(
            model_sync.element_unify_client.assets,
            get_dict("test/data/diff_unify_assets_computed.json"))
        self.assertEqual(
            model_sync.sitewise_handler.asset_models,
            get_dict("test/data/diff_sitewise_asset_models_computed.json"))
        self.assertEqual(
            model_sync.sitewise_handler.assets,
            get_dict("test/data/diff_sitewise_assets_computed.json"))
   
    def test_list_unify_data_model(self):
        model_sync = ElementUnifyModelSync()
        model_sync.secret_name = "imcUnifyTest001"
        model_sync.region_name = "us-east-1"
        (model_sync.hostname, model_sync.org_id, model_sync.username, model_sync.password) = get_element_unify_secrets(
            secret_name=model_sync.secret_name, region_name=model_sync.region_name)

        element_unify_client = ElementUnifyHandler(
            appname=model_sync.hostname,
            hostname=model_sync.hostname)
        element_unify_client.login(
            username=model_sync.username,
            password=model_sync.password)
        element_unify_client.select_org(
            org_id=model_sync.org_id)

        self.assertEqual(
            get_dict_str(element_unify_client.list_asset_templates()),
            get_dict_str(get_dict("test/data/diff_unify_templates.json")))
   
        self.assertEqual(
            get_dict_str(element_unify_client.list_assets()),
            get_dict_str(get_dict("test/data/diff_unify_assets.json")))

    def test_list_sitewise_data_model(self):
        sitewise_assets = SitewiseHandler()
        self.assertEqual(
            get_dict_str(sitewise_assets.list_asset_models()),
            get_dict_str(get_dict("test/data/diff_sitewise_asset_models.json")))

        sitewise_assets = sitewise_assets.list_assets()
        self.assertEqual(
            get_dict_str(sitewise_assets),
            get_dict_str(get_dict("test/data/diff_sitewise_assets.json")))

if __name__ == '__main__':
        unittest.main()

