# Copyright 2021 Element Analytics, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Element Unify SiteWise Connector imports existing AWS IoT SiteWise
asset models and asset hierarchies into Element Unify
"""

from datetime import datetime
import os
import logging
from unifyconnectorframework.organization_client import OrganizationClient as UnifyAgent
from unifyconnectorframework import utils
from helpers.sitewise_handler import SitewiseHandler
from helpers.helpers import write_data_to_csv

log = logging.getLogger('unifySiteWiseAgent')
log.setLevel(logging.INFO)

class ElementUnifySiteWiseAgent:
    """Imports existing AWS IoT SiteWise asset models and asset hierarchies into Element Unify
    It connects to the data model in SiteWise, uploads the asset model as asset templates,
    and uploads the asset hierarchy as a dataset.
    """
    def __init__(self, username, password, orgId, hostname, region_name, save_csv=False, upload_to_unify=True, template_suffix=''):
        self.appname = "unify"
        self.template_suffix = template_suffix
        self.hostname = hostname
        self.org_id = str(orgId)
        self.username = username
        self.password = password
        self.element_unify_handler = None
        self.sitewise_handler = None
        self.content_templates = None
        self.content_assets = None
        self.content_template_params = None
        self.region_name = region_name
        self.unify_agent = None
        self.upload_to_unify = upload_to_unify
        self.save_csv = save_csv

    def run(self, template_categories = ['AWS IoT SiteWise Import'],  dataset_labels = ['AWS IoT SiteWise Import']):
        """Connect to Element Unify and AWS IoT SiteWise and
        upload SiteWise asset models and assets to Element Unify
        """
        # Connect to Element Unify
        try:
            self.unify_agent = UnifyAgent(
                user_name=self.username,
                password=self.password,
                org_id=self.org_id,
                cluster=self.hostname)
        except Exception as error:
            logging.error('Failed to create Unify Agent, error: %s', error)

        # Connect to AWS IoT SiteWise
        self.sitewise_handler = SitewiseHandler(self.region_name)
        log.info("Retrieving SiteWise Asset Models")
        self.sitewise_handler.list_asset_models()
        log.info("Retrieving SiteWise Assets")
        self.sitewise_handler.list_assets()

        # Upload to Element Unify
        log.info("Uploading SiteWise asset models into Element Unify")
        self.create_update_asset_templates(
            sitewise_models=self.sitewise_handler.asset_models, categories = template_categories)

        log.info("Uploading SiteWise asset hierarchy into Element Unify")
        self.create_assets(
            sitewise_assets=self.sitewise_handler.assets, dataset_labels = dataset_labels)

    def create_update_asset_templates(self, sitewise_models, categories):
        """
        Creates or updates asset templates from SiteWise asset models

        :type sitewise_models: dict
        :param sitewise_models: Contains definition of the AWS IoT SiteWise
            asset models and properties.
        : type upload:bool
        :param upload: Upload the model as asset templates, or just store in memory
        """
        log.info("Creating or updating asset models")
        header_templates = ["Template Name", "Attribute", "Type", "UoM", "Attribute Type"]
        header_params = ["template", "attribute", "key", "value"]
        content_array = [header_templates]
        content_params_array = [header_params]
        template_names = set()
        for model in sitewise_models.values():
            template_name = f'{model["assetModelName"]}{self.template_suffix}'
            template_names.add(template_name)
            # set attributes from measurement and attribute properties
            for prop in model["assetModelProperties"].values():
                attribute_name = prop["name"]
                type_field = f'{prop["dataType"]}{self.template_suffix}'
                config_property_type = self.get_property_type(prop)
                attribute_type = self.get_attribute_type(config_property_type)
                attribute_uom = prop.get("unit", "")

                content_array.append([template_name, attribute_name, type_field,
                    attribute_uom, attribute_type])
                content_params_array.append([template_name, attribute_name,
                    "Property Type", config_property_type])
                config_default_value = self.get_property_default_value(prop)
                if config_default_value:
                    content_params_array.append([template_name, attribute_name,
                        "Default Value", config_default_value])

            # set attributes from asset model hierarchies
            for asset_model_hierarchy in model["assetModelHierarchies"]:
                attribute_name = asset_model_hierarchy["name"]
                type_field = f'{asset_model_hierarchy["name"]}{self.template_suffix}'
                attribute_type = "Continous Value"
                attribute_uom = ""
                content_array.append([template_name, attribute_name,
                    type_field, attribute_uom, attribute_type])

            # handle empty properties
            if len(model["assetModelProperties"].values()) == 0:
                content_array.append([template_name, "", "", "", ""])

        self.content_templates = write_data_to_csv(content_array)

        self.content_template_params = write_data_to_csv(content_params_array)

        if self.upload_to_unify:
            try:
                self.unify_agent.upload_template(self.content_templates)
                self.update_categories(
                    org_client=self.unify_agent,
                    template_names=list(template_names),
                    categories=categories)
                logging.info('template uploaded')
            except Exception as error:
                logging.error('Failed to upload and add categories to template, error: %s', error)
                raise error

            try:
                self.unify_agent.upload_template_configuration(self.content_template_params)
                logging.info('template configuration uploaded')
            except Exception as error:
                logging.error('Failed to upload template configuration, error: %s', error)

        if self.save_csv:
            try:
                utils.save_csv("sitewise_templates.csv", self.content_templates)
                utils.save_csv("sitewise_template_configuration.csv", self.content_template_params)
                logging.info('write templates to local')
            except Exception as error:
                logging.error('Failed to write csv, error: %s', error)

    @staticmethod
    def update_categories(org_client, template_names, categories):
        """
        Updates categories on asset templates

        :type org_client: OrganizationClient
        :param org_client: unify agent
        :type template_names: list
        :param template_names: list of template names to attach categories to
        :type categories: list
        :param categories: list of categories to assign to templates
        """
        try:
            templates_in_org = org_client.list_templates()
            template_dic = {}
            for template in templates_in_org:
                template_dic.update({template['name']: template})
            for name in template_names:
                template_id = template_dic[name]['id']
                version = template_dic[name]['version']
                org_client.update_template_categories(template_id, name, version, categories)
        except Exception as error:
            logging.error('Failed to add categories to templates')
            raise error

    @staticmethod
    def get_property_type(model_property):
        """
        Returns property type

        :type model_property: dict
        :param model_property: asset model property dictionary
        """
        for property_type in ["measurement", "attribute", "metric", "transform"]:
            if property_type in model_property["type"].keys():
                return property_type.capitalize()
        return "Measurement"

    @staticmethod
    def get_attribute_type(property_type):
        """
        Returns asset template attribute type from asset model property type

        :type property_type: str
        :param property_type: property type
        """
        if property_type == "Attribute":
            return "Static"
        return "Continous Value"

    @staticmethod
    def get_property_default_value(model_property):
        """
        Returns property default value

        :type model_property: dict
        :param model_property: asset model property dictionary
        """
        if model_property["type"].get("attribute") \
            and model_property["type"].get("attribute").get("defaultValue"):
            return model_property["type"]["attribute"].get("defaultValue", "")
        return ""

    def create_assets(self, sitewise_assets, dataset_labels):
        """
        Retrieve assets from SiteWise and uploads to Element Unify as a dataset

        :type sitewiseModels: dict
        :param sitewiseModels: Contains definition of the AWS IoT SiteWise
            asset models and properties.
        : type upload:bool
        :param upload: Upload the model as asset templates, or just store in memory
        """
        header = ["Mapping", "Asset Name", "Asset Model", "Asset Property", "Asset Path"]
        content_array = [header]
        for asset in sitewise_assets.values():
            asset_name = asset["assetName"]
            asset_model = f'{asset["assetModelName"]}{self.template_suffix}'
            asset_parents = []
            asset_parent_name = asset.get("parentName")
            while asset_parent_name:
                asset_parents.append(asset_parent_name)
                parent = sitewise_assets[asset_parent_name]
                asset_parent_name = parent.get("parentName")
            asset_path = "\\".join(asset_parents[::-1])

            for prop in asset["assetProperties"]:
                property_name = prop["name"]
                property_value = prop.get("alias", "")
                content_array.append([property_value, asset_name, asset_model,
                    property_name, asset_path])
            # handle empty properties
            if len(asset["assetProperties"]) == 0:
                content_array.append(["", asset_name, asset_model, "", asset_path])

        self.content_assets = write_data_to_csv(content_array)

        if self.upload_to_unify:
            try:
                dataset_name = "SiteWise {}".format(datetime.now().strftime("%m.%d.%Y %H.%M.%S"))
                logging.info("Uploading dataset %s" % dataset_name)
                dataset_id = self.unify_agent.create_dataset(dataset_name, self.content_assets)['data_set_id']
                logging.info("Dataset id is %s" % dataset_id)
                self.unify_agent.update_dataset_labels(dataset_id, dataset_labels)

                logging.info('Dataset %s uploaded', dataset_name)
            except Exception as error:
                logging.info('Failed to upload and label dataset %s, error: %s', dataset_name, error)
                raise error

        if self.save_csv:
            try:
                utils.save_csv("sitewise_assets.csv", self.content_assets)
                logging.info('Write assets dataset to local')
            except Exception as error:
                logging.error('Failed to write csv, error: %s', error)
