# Copyright 2021 Element Analytics, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
import csv
import io
import boto3
from botocore.exceptions import ClientError

def print_pretty(data, flat=False):
    """
    Set org reference
    :type org_id: str
    :param org_id: organization id
    """
    if flat:
        print("{}".format(json.dumps(data, default=str)))
    else:
        print("{}".format(json.dumps(data, indent=2, default=str)))

def lookup_dict(dictionary, key, match, return_key):
    """
    Return a dictionary from dictionary based on key value match
    :type dictionary: list
    :param dictionary: list of dicts
    :type key: str
    :param key: match key
    :type match: str
    :param match: match value
    :type return_key: str
    :param return_key: key of value to return
    """
    for child_dictionary in dictionary.values():
        if child_dictionary[key] == match:
            return child_dictionary[return_key]
    return None

def lookup_list(list_dict, key, match, return_key):
    """
    Return a dictionary from list based on key value match
    :type list_dict: list
    :param list_dict: list of dicts
    :type key: str
    :param key: match key
    :type match: str
    :param match: match value
    :type return_key: str
    :param return_key: key of value to return
    """
    for dictionary in list_dict:
        if dictionary[key] == match:
            return dictionary[return_key]
    return None

def get_dict_from_list_by_key(list_dict, dict_key, match):
    """
    Return a dictionary from list based on key value match
    :type list_dict: list
    :param list_dict: list of dicts
    :type dict_key: str
    :param dict_key: match key
    :type match: str
    :param match: match value
    """
    for dictionary in list_dict:
        if dictionary[dict_key] == match:
            return dictionary
    return None

def get_element_unify_secrets(secret_name, region_name):
    """
    Retrieve from secrets manager
    :type secret_name: str
    :param secret_name: name of secret manager
    :type region_name: region with secret manager
    :param region_name: region with secret manager
    """
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as err:
        raise err
    else:
        if "SecretString" in get_secret_value_response:
            secrets = json.loads(get_secret_value_response["SecretString"])
            if secrets.keys() >= {"user_id", "password", "cluster", "org_id"}:
                return (secrets["cluster"], secrets["org_id"], secrets["user_id"], secrets["password"])

    return ("", "", "", "")

def write_data_to_csv(data):
    """
    Write data represented as a list of list to csv
    :type data: list of list str
    :param data: data to write to csv
    """
    output = io.StringIO()
    writer = csv.writer(output, quoting=csv.QUOTE_NONNUMERIC)
    try:
        writer.writerows(data)
        return output.getvalue()
    except Exception as err:
        print('Failed to convert data to csv. Data: %s, error: %s', json.dumps(data, default=str), err)

class CaseInsensitiveDictReader(csv.DictReader):
    @property
    def fieldnames(self):
        return [field.strip().lower() for field in csv.DictReader.fieldnames.fget(self)]

    def next(self):
        return CaseInsensitiveDictReader(csv.DictReader.next(self))

class CaseInsensitiveDict(dict):
    # This class overrides the __getitem__ method to automatically strip() and lower() the input key

    def __getitem__(self, key):
        return dict.__getitem__(self, key.strip().lower())

class Log():
    def __init__(self):
        self.logs = boto3.client('logs')
