"""
A organiaztion client includes methods needed for agents.
"""
import logging
from unify.properties import Properties, ClusterSetting
from unify.orgadmin import OrgAdmin
from unify.sources import Sources
from unify.templates import Templates


class OrganizationClient:
    """
    Common agent class
    """
    def __init__(self, user_name, password, org_id, cluster):
        self.user_name = user_name
        self.password = password
        self.org_id = org_id
        self.cluster = cluster

        self.app_name = 'imc'
        self.props = Properties(ClusterSetting.MEMORY)
        self.props.store_cluster(user_name, password, cluster, self.app_name)
        try:
            org_admin = OrgAdmin(self.app_name, self.props)
            token = org_admin.auth_token()
            self.props.set_auth_token(
                token=token,
                cluster=self.app_name
            )
        except Exception as error:
            logging.error('Failed to login. %s', error)
            raise error

        try:
            self.sources = Sources(self.app_name, self.props)
            self.templates = Templates(self.app_name, self.props)
        except Exception as error:
            logging.error('Failed to get organization sources client.')
            raise error

        try:
            self.templates = Templates(self.app_name, self.props)
        except Exception as error:
            logging.error('Failed to get organization templates client.')
            raise error

    def list_datasets(self):
        """
        Retrieve all datasets.
        """
        return self.sources.get_sources(org_id=self.org_id)

    def create_dataset(self, name, dataset_csv):
        """
        Create a new dataset.
        :type name: string
        :param name: Name of dataset
        :type dataset_csv: string
        :param dataset_csv: Content to upload
        """
        return self.sources.create_api_data_set_with_content(name, self.org_id, dataset_csv)

    def update_dataset(self, dataset_csv, dataset_name=None, dataset_id=None):
        """
        Update a dataset. If dataset does not exist, create a new dataset.
        :type dataset_csv: string
        :param dataset_csv: Content to upload
        :type dataset_name: string
        :param dataset_name: Name of dataset
        :type dataset_id: string
        :param dataset_id: Existing dataset id
        """
        existing_datasets = [dataset.get("id") for dataset in self.list_datasets()]
        if dataset_id is None or dataset_id not in existing_datasets:
            response = self.create_dataset(name=dataset_name, dataset_csv=dataset_csv)
            dataset_id = response.get("data_set_id")
        else:
            self.truncate_dataset(dataset_id=dataset_id)
            self.append_dataset(dataset_id=dataset_id, dataset_csv=dataset_csv)
        return dataset_id

    def truncate_dataset(self, dataset_id):
        """
        Truncate a dataset.
        :type dataset_id: string
        :param dataset_id: Existing dataset id
        """
        return self.sources.truncate_data_set(org_id=self.org_id, data_set_id=dataset_id)

    def append_dataset(self, dataset_id, dataset_csv):
        """
        Append a dataset.
        :type dataset_csv: string
        :param dataset_csv: Content to upload
        :type dataset_id: string
        :param dataset_id: Existing dataset id
        """
        return self.sources.append_dataset(
            org_id=self.org_id,
            data_set_id=dataset_id,
            content=dataset_csv)

    def update_dataset_labels(self, dataset_id, labels):
        """
        Updates labels for a dataset.
        :type dataset_id: string
        :param dataset_id: Existing dataset id
        :type labels: dict
        :param labels: Labels
        """
        return self.sources.label(self.org_id, dataset_id, labels)

    def upload_template(self, template_csv):
        """
        Upload asset template definition csv.
        :type template_csv: string
        :param template_csv: asset template definition in csv format
        """
        return self.templates.upload_string_content_file(self.org_id, template_csv)

    def upload_template_configuration(self, config_csv):
        """
        Upload asset template configuration parameter definition csv.
        :type config_csv: string
        :param config_csv: asset template configuration parameter definition in csv format
        """
        return self.templates.upload_config_with_content(self.org_id, config_csv)

    def update_template_categories(self, template_id, template_name, version, categories):
        """
        Update categories to an asset template.
        :type template_id: string
        :param template_id: Existing template id
        :type template_name: string
        :param template_name: Existing template name
        :type version: string
        :param version: Existing template id
        :type categories: dict
        :param categories: Labels
        """
        return self.templates.category(self.org_id, template_id, template_name, version, categories)

    def list_templates(self):
        """
        Retrieve all asset templates
        """
        return self.templates.list_asset_templates(self.org_id)
