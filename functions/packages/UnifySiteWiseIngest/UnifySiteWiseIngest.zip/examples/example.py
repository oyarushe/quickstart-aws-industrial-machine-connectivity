import sys
import os

from unify_sitewise_agent import ElementUnifySiteWiseAgent

if __name__ == '__main__':
    agent = ElementUnifySiteWiseAgent(
        username=os.environ.get('username'),
        password=os.environ.get('password'),
        orgId=22,
        hostname='https://app001-aws.elementanalytics.com/',
        region_name='us-west-2',
        save_csv=True,
        upload_to_unify=True,
        template_suffix='')
    agent.run()
