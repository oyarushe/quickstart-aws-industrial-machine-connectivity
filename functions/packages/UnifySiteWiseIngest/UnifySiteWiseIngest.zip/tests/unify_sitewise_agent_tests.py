# Copyright 2021 Element Analytics, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Unify SiteWise Agent Tests
"""
import unittest
import json
import os
from unify_sitewise_agent.unify_sitewise_agent import ElementUnifySiteWiseAgent
from helpers.sitewise_handler import SitewiseHandler

def get_dict_from_file(filename):
    """
    Load contents from file as a dict
    :type filename: str
    :param filename: name of test file
    """
    with open(filename, "r") as file_reader:
        contents = file_reader.read()
        try:
            return json.loads(contents)
        except FileNotFoundError:
            return {}

def get_file_contents(filename):
    """
    Load contents from file as a str
    :type filename: str
    :param filename: name of test file
    """
    with open(filename, "r") as file_reader:
        try:
            return file_reader.read()
        except FileNotFoundError:
            return None

def get_dict_str(dict_object):
    """
    Retrieve string representation of dict
    :type dict: dict
    :param dict: dictionary
    """
    return json.dumps(dict_object, indent=2, default=str)

class ElementUnifySiteWiseTest(unittest.TestCase):
    """
    Tests
    """
    def test_list_sitewise_data_model(self):
        """
        Ensure retrieved sitewise objects match standardized representation
        """
        username = os.environ.get('username')
        password = os.environ.get('password')
        org_id = os.environ.get('orgId')
        hostname = os.environ.get('hostname')
        template_suffix = os.environ.get('templateSuffix')
        region_name = os.environ.get('regionName')
        model_sync = ElementUnifySiteWiseAgent(username, password, org_id, hostname, template_suffix)
        model_sync.sitewise_handler = SitewiseHandler(region_name=region_name)
        model_sync.sitewise_handler.list_asset_models()
        model_sync.sitewise_handler.list_assets()

        model_sync.create_update_asset_templates(
            sitewise_models=model_sync.sitewise_handler.asset_models)
        model_sync.create_assets(
            sitewise_assets=model_sync.sitewise_handler.assets)

        self.assertEqual(
            get_dict_str(get_dict_from_file('test/data/sitewise_connector_models.json')),
            get_dict_str(model_sync.sitewise_handler.asset_models)
        )

        self.assertEqual(
            get_dict_str(get_dict_from_file('test/data/sitewise_connector_assets.json')),
            get_dict_str(model_sync.sitewise_handler.assets)
        )

        self.assertEqual(
            get_file_contents('test/data/sitewise_connector_templates.csv'),
            model_sync.content_templates
        )

        self.assertEqual(
            get_file_contents('test/data/sitewise_connector_template_params.csv'),
            model_sync.content_template_params
        )

        self.assertEqual(
            get_file_contents('test/data/sitewise_connector_assets.csv'),
            model_sync.content_assets
        )

if __name__ == '__main__':
    unittest.main()
