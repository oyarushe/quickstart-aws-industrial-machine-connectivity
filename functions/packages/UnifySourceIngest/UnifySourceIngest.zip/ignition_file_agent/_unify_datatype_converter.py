# convert ignition datatype to unify datatype for templates
# ignition datatypes: https://docs.inductiveautomation.com/display/DOC80/Tag+Data+Types
# unify datatypes: Boolean, Double, String, Integer

mapping = {
    'Int1': 'Integer',
    'Int2': 'Integer',
    'Int4': 'Integer',
    'Int8': 'Integer',
    'Float4': 'Double',
    'Float8': 'Double',
    'Boolean': 'Boolean',
    'String': 'String',
    'DateTime': 'String',
    'Text': 'String',
    'Int1Array': 'String',
    'Int2Array': 'String',
    'Int4Array': 'String',
    'Int8Array': 'String',
    'Float4Array': 'String',
    'Float8Array': 'String',
    'BooleanArray': 'String',
    'StringArray': 'String',
    'DateTimeArray': 'String',
    'ByteArray': 'String',
    'DataSet': 'String',
    'Document': 'String'
}
def unify_datatype(ignition_type):
    return mapping.get(ignition_type, 'String')