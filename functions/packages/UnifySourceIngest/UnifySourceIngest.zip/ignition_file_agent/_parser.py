import collections.abc
from datetime import date, datetime
import json
import logging
import os
import re
import sys
import time
import itertools
from typing import List
log = logging.getLogger('assetModelConverter')
log.setLevel(logging.DEBUG)


def normalize(items):
    return {item['name']: item for item in items}

DELIMITER = '/'

class _Parser:
    def __init__(self, fileDataList):
        self.fileDataList = fileDataList
        self.rawData = {}
        self.rawModels = {}
        self.rawAssets = []

        self.modelPropertyMap = {}
        self.normalizedModels = {}
        self.assets = []
        self.sensors= []

        self.unifyDataset = []
        self.unifyTemplates = []

        self.tagBlacklist = ['Sim Controls']
    

    def __updateDict(self, baseData, updateData):
        for key, value in updateData.items():
            if isinstance(value, collections.abc.Mapping):
                baseData[key] = self.updateDict(baseData.get(key, {}), value)
            else:
                baseData[key] = value

        return baseData

    def __getRawData(self):
        for fileData in self.fileDataList:
            self.__updateDict(self.rawData, fileData)
    
    def __getRawModels(self, record, parent_path):
         for modelTag in record.get('tags', []):
            if(parent_path == ''):
                tag_path = modelTag['name'] 
            else:
                tag_path = '{}/{}'.format(parent_path, modelTag['name'])
            
            if modelTag['tagType'] == 'UdtType':
                self.rawModels[tag_path] = modelTag
            elif  modelTag['tagType'] == 'Folder':
                self.__getRawModels(modelTag, tag_path)
            else:
                raise Exception('Can not support tagType:${} under __type__'.format(modelTag['tagType']))

    def __getRawModelAndAsset(self):
        for record in self.rawData['tags']:
            if record['name'] in self.tagBlacklist:
                continue

            if record['name'] == '_types_':
                self.__getRawModels(record, '')
            else:
                self.rawAssets.append(record)


    """
    convert raw model node to get properties and hierachies
    """
    def __parseModelNode(self, model, name_path):
        modelNode = {
            'name': name_path,
            'properties': {},
            'hierarchies': [],
        }
        for metric in model.get('tags', []):
            if(metric['tagType'] == 'AtomicTag'):
                modelNode['properties'][metric['name']] = metric
            elif(metric['tagType'] == 'UdtInstance'):
                modelNode['hierarchies'].append({
                  'name': metric['name'],
                  'type': metric['typeId']
                })
            else:
                print('****')#to do for folder
        
        return modelNode
    

    def __genAssetNode(self, nodeName, nodeValue, baseModel, parentName=''):
        assetNode = {
            'assetName': nodeName,
            'modelName': baseModel,
            'parentName': parentName,
            'sensors': [],
            'accociate_assets': []
        }
        modelNode = self.normalizedModels.get(baseModel, {})
        normalizedTags = normalize(nodeValue['tags'])

        properties = modelNode.get('properties', {})
       
        for propertyName in properties:
            fields = self.normalizedModels[baseModel]['properties'][propertyName]
            tagEntry = {
              **properties[propertyName],  #model property fields
              **normalizedTags[propertyName]  # assert Node sensor fields
            }
            if('parameters' in nodeValue):
              parameters = nodeValue['parameters']
              resolvedOpcPath = fields['opcItemPath']['binding'].format(**parameters)
              tagEntry = {
                  **tagEntry,
                  'opcItemPath':  resolvedOpcPath,
              }
            assetNode['sensors'].append(tagEntry)
        
        # generate accociate assets
        hierachies = modelNode.get('hierarchies', [])
        for hierachy in hierachies:
          accociateAssetName = nodeName + DELIMITER + hierachy['name']
          self.assets.append(
              self.__genAssetNode(
                  accociateAssetName,
                  normalizedTags[hierachy['name']],
                  hierachy['type'],
                  nodeName)
                )
          assetNode['accociate_assets'].append({
            'name': hierachy['name'],
            'accociateTo': accociateAssetName
          })

        return assetNode

    def __processAssetTree(self, nodeValue, parentPath=''):       
        nodePath = parentPath + DELIMITER + nodeValue['name']
        nodeType = self.__getAssetNodeType(nodeValue)
        
        if (nodeType == 'sensor'):  # replace name with full name 
            self.sensors.append({
                **nodeValue,
                'name': nodePath,
            })
        elif(nodeType == 'asset'):
            base_model_name = nodeValue['typeId']
            new_base_model_name = base_model_name.replace('/', DELIMITER)
            assetNode = self.__genAssetNode(
                nodeName=nodePath,
                nodeValue=nodeValue,
                baseModel=new_base_model_name,
                parentName=parentPath,
            )
            self.assets.append(assetNode)
        else:
            for childValue in nodeValue['tags']:
                self.__processAssetTree(
                    nodeValue=childValue,
                    parentPath=nodePath,
                )   
      

    def __getAssetNodeType(self, nodeValue):
        if nodeValue['tagType'] == 'UdtInstance':
            return 'asset'
        if nodeValue['tagType'] == 'AtomicTag':
            return 'sensor'
        else:
            return 'folder'

    def process(self):
        self.__getRawData()
        self.__getRawModelAndAsset()
        self.normalizedModels =  {name: self.__parseModelNode(model, name) for name, model in self.rawModels.items()}
        for assetGroup in self.rawAssets:
            self.__processAssetTree(assetGroup)

        
