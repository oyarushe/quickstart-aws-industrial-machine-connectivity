from common.organiztion_client import OrganizationClient
from common import utils 
from ignition_file_agent._parser import _Parser
from ignition_file_agent import _converter
import logging

logging.basicConfig(level=logging.INFO)

class Agent:
    def __init__(self, username, password, orgId, cluster, saveCsv=False, uploadToUnify=False):
        self.userName = username
        self.password = password
        self.orgId = orgId
        self.cluster = cluster
        self._saveCsv = saveCsv
        self.uploadToUnify = uploadToUnify
    
    def _category(self, org_client, template_names, labels):
        try:
            templates_in_org = org_client.list_templates()
            template_dic = {}
            for t in templates_in_org:
                template_dic.update({t['name']: t})
            for name in template_names:
                if name in template_dic:
                    id = template_dic[name]['id']
                    version = template_dic[name]['version']
                    org_client.update_template_categories(id, name, version, labels)
        except Exception as error:
            logging.error('Failed to category templates')
            raise error


    def ingest(self, file_data_list, site_name = 'default', server_name = 'default', append_template_prefix = False, labels=[]):
        tag_provider = '/Tag Providers/default'
        parser = _Parser(file_data_list)
        try:
            parser.process()
            datasetCsv = _converter.unifyDatasetCsv(parser.assets, parser.sensors, site_name, server_name, tag_provider)
            templates = [value for value in parser.normalizedModels.values()]
            if append_template_prefix:
                prefix = '{}-{}-'.format(site_name, server_name)
                templateCsv = _converter.unifyTemplateCsv(templates, prefix)
                template_names = map(lambda tn: prefix + tn, list(parser.normalizedModels.keys()))
            else:
                templateCsv = _converter.unifyTemplateCsv(templates)
                template_names = list(parser.normalizedModels.keys())
        except Exception as error:
            logging.error('Failed to parse ignition json file. error: %s', error)
            raise error

        if self.uploadToUnify:   
            datasetName = utils.get_name('{}-{}-ignition'.format(site_name, server_name))
            try:
                org_client = OrganizationClient(self.userName, self.password, self.orgId, self.cluster)
                dataset_id = org_client.create_dataset(datasetName, datasetCsv)['data_set_id']
                org_client.update_dataset_labels(dataset_id, labels)
                org_client.upload_template(templateCsv)
                self._category(org_client, template_names, labels)
            except Exception as error:
                logging.error('Failed to upload and category template, error: %s', error)
                raise error
            logging.info('upload dataset %s and templats to Unify, cluster: %s, organization: %d', datasetName, self.cluster, self.orgId)

        if self._saveCsv:
            try:
                utils.save_csv("{}_{}_dataset.csv".format(site_name, server_name), datasetCsv)
                utils.save_csv("{}_{}_tempaltes.csv".format(site_name, server_name), templateCsv)
                logging.info('write dataset and templates to local')
            except Exception as error:
                logging.error('Failed to write csv, error: %s', error)
                raise error


        
