import itertools
from common import utils
from ignition_file_agent._dataset_headers import *
from ignition_file_agent import _template_headers as th
from ignition_file_agent._parser import DELIMITER
from ignition_file_agent._unify_datatype_converter import unify_datatype

datasetSchema = [
    SITE,
    SERVER,
    NAME,
    ASSET_MODEL,
    ASSET_NAME,
    ASSET_PATH,
    PROPERTY_NAME,
    UNIT_OF_MEASURE,
    DATA_TYPE,
    SOURCE,
    OPC_PATH
]

tempalteSchema = [th.TEMPLATE_NAME, th.ATTRIBUTE, th.DATA_TYPE, th.UNIT_OF_MEASURE,  th.ATTRIBUTE_TYPE]


def _propertiesFromTemplate(template, prefix):
        properties = []
        template_name = template['name']
        for property in template['properties'].values():
            properties.append(
                {
                    th.TEMPLATE_NAME: prefix + template_name,
                    th.ATTRIBUTE: property['name'],
                    th.DATA_TYPE: unify_datatype(property.get('dataType', '')),
                    th.UNIT_OF_MEASURE: property.get('engUnit', ''),
                    th.ATTRIBUTE_TYPE: ''
                }
            )
        return properties

def _hierarchy_from_template(template, prefix):
    hierachies = []
    tempalte_name = template['name']
    for hierarchy in template['hierarchies']:
        hierachies.append(
            {
                th.TEMPLATE_NAME: prefix + tempalte_name,
                th.ATTRIBUTE: hierarchy['name'],
                th.DATA_TYPE: prefix + hierarchy.get('type', ''),
                th.UNIT_OF_MEASURE: '',
                th.ATTRIBUTE_TYPE: ''
            }
        )
    return hierachies

def _sensorFromSensorTag(sensor):
    return {
        NAME: sensor['name'],
        ASSET_MODEL: '',
        ASSET_NAME: '',
        ASSET_PATH: '',
        PROPERTY_NAME: '',
        UNIT_OF_MEASURE: sensor.get('engUnit', ''),
        DATA_TYPE: sensor.get('dataType', ''),
        SOURCE: sensor.get('valueSource', ''),
        OPC_PATH: sensor.get('opcItemPath', '')
    }

def _sensorsFromAsset(asset):
    assetSensors = []
    for sensor in asset['sensors']:
        assetSensors.append(
            {
                NAME: asset['assetName'] + '\\' + sensor['name'],
                ASSET_MODEL: asset['modelName'],
                ASSET_NAME: asset['assetName'].split(DELIMITER)[-1],
                ASSET_PATH: asset['parentName'],
                PROPERTY_NAME: sensor['name'],
                UNIT_OF_MEASURE: sensor.get('engUnit', ''),
                DATA_TYPE: sensor.get('dataType', ''),
                SOURCE: sensor.get('valueSource', ''),
                OPC_PATH: sensor.get('opcItemPath', '')
            }
        )
    return assetSensors

def unifyDatasetCsv(assets, sensors, site_name = '', server_name = '', tag_provider=''):
    assetSensors = list(itertools.chain(*map(_sensorsFromAsset, assets)))
    allSensors = list(map(_sensorFromSensorTag, sensors)) + assetSensors
    appended_meta = map(
        lambda sensor: {**sensor, SITE: site_name, SERVER: server_name, NAME: tag_provider + sensor[NAME]},
        allSensors
    )
    return utils.serialize_csv(datasetSchema, appended_meta)

def unifyTemplateCsv(templates, prefix = ''):
    attributes = list(itertools.chain(*map(lambda t: _propertiesFromTemplate(t, prefix), templates)))
    hierachies = list(itertools.chain(*map(lambda t: _hierarchy_from_template(t, prefix), templates)))
    return utils.serialize_csv(tempalteSchema, attributes + hierachies)

