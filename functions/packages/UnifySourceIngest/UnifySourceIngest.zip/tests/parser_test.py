import unittest
import json
from ignition_file_agent._parser import _Parser
from tests.json_test_data import udt_types, udt_types_hierachies, sensor, assets, assets_overwrite_model

class ParserTest(unittest.TestCase):
    
    def checkModel(self, tagsString, expectedString):
        parser = _Parser([json.loads(tagsString)])
        parser.process()
        self.assertDictEqual(parser.normalizedModels, json.loads(expectedString))

    def test_model_properties(self):       
        self.checkModel(udt_types.tags, udt_types.expected)
      
    def test_model_hierarchies(self):
        self.checkModel(udt_types_hierachies.tags, udt_types_hierachies.expectedModel)
    

    def test_sesor(self):
        parser = _Parser([json.loads(sensor.tags)])
        parser.process()
        self.assertListEqual(parser.sensors, sensor.expected)

    def test_assets(self):
        parser = _Parser([json.loads(assets.tags)])
        parser.process()
        self.assertListEqual(parser.assets, assets.expected)

    def test_assets_overwrite_model_eng_unit(self):
        parser = _Parser([json.loads(assets_overwrite_model.tags)])
        parser.process()
        self.assertListEqual(parser.assets, assets_overwrite_model.expected)
    
    def test_assets_hierarchies(self):
        parser = _Parser([json.loads(udt_types_hierachies.tags)])
        parser.process()
        self.assertListEqual(parser.assets, udt_types_hierachies.expectedAssets)

if __name__ == '__main__':
    unittest.main()