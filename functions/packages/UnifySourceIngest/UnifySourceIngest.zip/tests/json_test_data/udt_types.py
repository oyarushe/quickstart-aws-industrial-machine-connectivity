tags = '''{
      "name": "",
      "tagType": "Provider",
      "tags": [
        {
          "name": "_types_",
          "tagType": "Folder",
          "tags": [
            {
              "name": "Conveyer",
              "typeId": "",
              "parameters": {
                "Line": "",
                "Device": ""
              },
              "tagType": "UdtType",
              "tags": [
                {
                  "opcItemPath": {
                    "bindType": "parameter",
                    "binding": "ns\u003d1;s\u003d[{Device}]{Line}/Conveyor/Vibration"
                  },
                  "valueSource": "opc",
                  "accessRights": "Read_Only",
                  "dataType": "Float4",
                  "engHigh": 1500.0,
                  "name": "Vibration",
                  "engUnit": "hz",
                  "tagType": "AtomicTag",
                  "opcServer": "Ignition OPC UA Server"
                }
              ]
            }
          ]
        }
      ]
    }'''

expected = '''
  {
    "Conveyer": {
        "hierarchies": [],
        "name": "Conveyer",
        "properties": {
            "Vibration": {
                "accessRights": "Read_Only",
                "dataType": "Float4",
                "engHigh": 1500.0,
                "engUnit": "hz",
                "name": "Vibration",
                "opcItemPath": {
                    "bindType": "parameter",
                    "binding": "ns=1;s=[{Device}]{Line}/Conveyor/Vibration"
                },
                "opcServer": "Ignition OPC UA Server",
                "tagType": "AtomicTag",
                "valueSource": "opc"
            }
        }
    }
  }
'''