tags = '''
{
    "name": "",
    "tagType": "Provider",
    "tags": [
        {
            "name": "A2",
            "tagType": "Folder",
            "tags": [
                {
                    "name": "47",
                    "tagType": "Folder",
                    "tags": [
                        {
                            "dataType": "Float4",
                            "name": "47DPI19466_PV",
                            "opcItemPath": "ns=1;s=[Simulation]A01/47/47DPI19466.PV",
                            "opcServer": "Ignition OPC UA Server",
                            "tagType": "AtomicTag",
                            "valueSource": "opc"
                        },
                        {
                            "dataType": "Float4",
                            "name": "47DPI19465_PV",
                            "opcItemPath": "ns=1;s=[Simulation]A01/47/47DPI19465.PV",
                            "opcServer": "Ignition OPC UA Server",
                            "tagType": "AtomicTag",
                            "valueSource": "opc"
                        }
                    ]
                }
            ]
        }
    ]
}
'''


expected = [
    {
        "dataType": "Float4",
        "name": "\\A2\\47\\47DPI19466_PV",
        "opcItemPath": "ns=1;s=[Simulation]A01/47/47DPI19466.PV",
        "opcServer": "Ignition OPC UA Server",
        "tagType": "AtomicTag",
        "valueSource": "opc"
    },
    {
        "dataType": "Float4",
        "name": "\\A2\\47\\47DPI19465_PV",
        "opcItemPath": "ns=1;s=[Simulation]A01/47/47DPI19465.PV",
        "opcServer": "Ignition OPC UA Server",
        "tagType": "AtomicTag",
        "valueSource": "opc"
    }
]