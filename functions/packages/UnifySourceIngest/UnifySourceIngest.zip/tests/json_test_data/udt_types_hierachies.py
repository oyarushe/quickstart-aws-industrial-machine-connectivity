# define MaryModel and Line 1/MaryTag
tags = '''{
      "name": "",
      "tagType": "Provider",
      "tags": [
        {
          "name": "_types_",
          "tagType": "Folder",
          "tags": [
            {
              "name": "Conveyer",
              "typeId": "",
              "parameters": {
                "Line": "",
                "Device": ""
              },
              "tagType": "UdtType",
              "tags": [
                {
                  "opcItemPath": {
                    "bindType": "parameter",
                    "binding": "ns\u003d1;s\u003d[{Device}]{Line}/Conveyor/Vibration"
                  },
                  "valueSource": "opc",
                  "accessRights": "Read_Only",
                  "dataType": "Float4",
                  "engHigh": 1500.0,
                  "name": "Vibration",
                  "engUnit": "hz",
                  "tagType": "AtomicTag",
                  "opcServer": "Ignition OPC UA Server"
                }
              ]
            },
            {
              "name": "MaryModel",
              "tagType": "UdtType",
              "tags": [
                {
                  "valueSource": "opc",
                  "name": "temperator",
                  "tagType": "AtomicTag"
                },
                {
                  "name": "useConveyer",
                  "typeId": "Conveyer",
                  "tagType": "UdtInstance",
                  "tags": [
                    {
                      "name": "Vibration",
                      "tagType": "AtomicTag"
                    }
                  ]
                }
              ]
            }
          ]
        },
        {
          "name": "Line 1",
          "tagType": "Folder",
          "tags": [
            {
              "name": "maryTag",
              "typeId": "MaryModel",
              "tagType": "UdtInstance",
              "tags": [
                {
                  "name": "useConveyer",
                  "tagType": "UdtInstance",
                  "parameters": {
                      "Device": "Simulation",
                      "Line": "Line 1"
                  },
                  "tags": [
                    {
                      "engUnit": "F",
                      "name": "Vibration",
                      "tagType": "AtomicTag"
                    }
                  ]
                },
                {
                  "name": "temperator",
                  "tagType": "AtomicTag"
                }
              ]
            }
          ]
        }
      ]
    }'''

expectedModel = '''
  {
    "Conveyer": {
        "hierarchies": [],
        "name": "Conveyer",
        "properties": {
            "Vibration": {
                "accessRights": "Read_Only",
                "dataType": "Float4",
                "engHigh": 1500.0,
                "engUnit": "hz",
                "name": "Vibration",
                "opcItemPath": {
                    "bindType": "parameter",
                    "binding": "ns=1;s=[{Device}]{Line}/Conveyor/Vibration"
                },
                "opcServer": "Ignition OPC UA Server",
                "tagType": "AtomicTag",
                "valueSource": "opc"
            }
        }
    },
    "MaryModel": {
      "name": "MaryModel",
      "properties": {
        "temperator": {"valueSource": "opc", "name": "temperator", "tagType": "AtomicTag"}
      },
      "hierarchies": [
        {"name": "useConveyer", "type": "Conveyer"}
      ]
    }
  }
'''


expectedAssets =[
    {
        "assetName": "\\Line 1\\maryTag\\useConveyer",
        "modelName": "Conveyer",
        "parentName": "\\Line 1\\maryTag",
        "sensors": [
            {
              "accessRights": "Read_Only",
              "dataType": "Float4",
              "engHigh": 1500.0,
              "engUnit": "F",
              "name": "Vibration",
              "opcItemPath": "ns=1;s=[Simulation]Line 1/Conveyor/Vibration",
              "opcServer": "Ignition OPC UA Server",
              "tagType": "AtomicTag",
              "valueSource": "opc",
            }
        ],
         "accociate_assets": []
    },
    {
        "assetName": "\\Line 1\\maryTag",
        "modelName": "MaryModel",
        "parentName": "\\Line 1",
        "sensors": [
            {
              "name": "temperator",
              "tagType": "AtomicTag",
              "valueSource": "opc",
            }
        ],
        "accociate_assets": [
          {
            "name": "useConveyer",
            "accociateTo": "\\Line 1\\maryTag\\useConveyer"
          }
        ]
    }
]
