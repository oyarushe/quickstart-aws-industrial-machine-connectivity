tags = '''{
      "name": "",
      "tagType": "Provider",
      "tags": [
        {
          "name": "_types_",
          "tagType": "Folder",
          "tags": [
            {
              "name": "Conveyer",
              "typeId": "",
              "parameters": {
                "Line": "",
                "Device": ""
              },
              "tagType": "UdtType",
              "tags": [
                {
                  "opcItemPath": {
                    "bindType": "parameter",
                    "binding": "ns\u003d1;s\u003d[{Device}]{Line}/Conveyor/Vibration"
                  },
                  "valueSource": "opc",
                  "accessRights": "Read_Only",
                  "dataType": "Float4",
                  "engHigh": 1500.0,
                  "name": "Vibration",
                  "engUnit": "hz",
                  "tagType": "AtomicTag",
                  "opcServer": "Ignition OPC UA Server"
                }
              ]
            }
          ]
        },
        {
          "name": "Line 2",
          "tagType": "Folder",
          "tags": [
            {
              "name": "Conveyor",
              "parameters": {
                  "Device": "Simulation",
                  "Line": "Line 2"
              },
              "tagType": "UdtInstance",
              "tags": [
                  {
                      "name": "Vibration",
                      "tagType": "AtomicTag"
                  }
              ],
              "typeId": "Conveyer"
            }
          ]
        }
      ]
    }'''


expected = [
    {
        "assetName": "\\Line 2\\Conveyor",
        "modelName": "Conveyer",
        "parentName": "\\Line 2",
        "sensors": [
            {
                "accessRights": "Read_Only",
                "dataType": "Float4",
                "engHigh": 1500.0,
                "engUnit": "hz",
                "name": "Vibration",
                "opcItemPath": "ns=1;s=[Simulation]Line 2/Conveyor/Vibration",
                "opcServer": "Ignition OPC UA Server",
                "tagType": "AtomicTag",
                "valueSource": "opc"
            }
        ],
        "accociate_assets": []
    }
]
