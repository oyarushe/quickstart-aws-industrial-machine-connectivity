
import logging
import itertools


class _Parser:
    def __init__(self, fileDataList):
        self._fileDataList = fileDataList
        self.unifyDataset = []
    

    def __getTag(self, tag, parentPath):
        tag = {
            'name': '{}/{}'.format(parentPath, tag.get('common.ALLTYPES_NAME', '')),
            'description': tag.get('common.ALLTYPES_DESCRIPTION', ''),
            'data_type': tag.get('servermain.TAG_DATA_TYPE', -1),
            'uom': tag.get('servermain.TAG_SCALING_UNITS', ''),
        }
        return tag

    def __tagsFromGroup(self, group, parentPath):
        if 'tags' in group:        
            tags = list(map(lambda t: self.__getTag(t, parentPath), group['tags']))
        else:
            tags = []
        
        if 'tag_groups' in group:
            otherTags = list(
                itertools.chain(*map(
                    lambda g: self.__tagsFromGroup(g, parentPath + '/' + g['common.ALLTYPES_NAME']),
                    group.get('tag_groups')
                ))
            )
        else:
            otherTags = []
        return tags + otherTags

    def _processFile(self, model_file_data):
        tagsWithMeta = []
        project = model_file_data['project']['servermain.PROJECT_TITLE']
        for channel in model_file_data['project']['channels']:
            channel_name = channel['common.ALLTYPES_NAME']
            for device in channel['devices']:
                device_name = device['common.ALLTYPES_NAME']
                parentPath = '{}/{}/{}'.format(project, channel_name, device_name)
                tags = self.__tagsFromGroup(device, parentPath)
                tagsWithMeta += list(map(lambda t: {
                    'project': project,
                    'channel': channel_name,
                    'device': device_name,
                    **t,
                }, tags))
        return tagsWithMeta                

    def process(self):
        self.unifyDataset = list(itertools.chain(*map(self._processFile, self._fileDataList)))