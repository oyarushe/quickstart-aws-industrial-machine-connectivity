from kepserver_file_agent._dataset_headers import *
from common import utils
from enum import Enum

dataset_schema = [NAME, DESCRIPTION, PROJECT, CHANNEL, DEVICE, DATA_TYPE, UOM]

DataTypeEnum = Enum(
    value = 'DataTypeEnum',
    names = [
        ("Default", -1),
        ("String", 0),
        ("Boolean", 1),
        ("Char", 2),
        ("Byte", 3),
        ("Short", 4),
        ("Word", 5),
        ("Long", 6),
        ("DWord", 7),
        ("Float", 8),
        ("Double", 9),
        ("BCD", 10),
        ("LBCD", 11),
        ("Date", 12),
        ("LLong", 13),
        ("QWord", 14),
        ("String Array", 20),
        ("Boolean Array", 21),
        ("Char Array", 22),
        ("Byte Array", 23),
        ("Short Array", 24),
        ("Word Array", 25),
        ("Long Array", 26),
        ("DWord Array", 27),
        ("Float Array", 28),
        ("Double Array", 29),
        ("BCD Array", 30),
        ("LBCD Array", 31),
        ("Date Array", 32),
        ("LLong Array", 33),
        ("QWord Array", 34),
    ]
)

dataset_schema = [
    SITE,
    SERVER,
    NAME,
    DESCRIPTION,
    PROJECT,
    CHANNEL,
    DEVICE,
    DATA_TYPE,
    UOM,
]

def _convert_dataset_header(tag):
    return {
        PROJECT: tag['project'],
        CHANNEL: tag['channel'],
        DEVICE: tag['device'],
        NAME: tag['name'],
        DESCRIPTION: tag['description'],
        DATA_TYPE: DataTypeEnum(tag['data_type']).name,
        UOM: tag['uom'],
    }

def unifyDatasetCsv(tags, site_name='', server_name=''):
    converted = list(map(_convert_dataset_header, tags))
    appended_meta = map(lambda t: {**t, SITE: site_name, SERVER: server_name}, converted)
    return utils.serialize_csv(dataset_schema, appended_meta)
