import json
import logging
from common import utils
from common.organiztion_client import OrganizationClient
from kepserver_file_agent._parser import _Parser
from kepserver_file_agent import _converter

logging.basicConfig(level=logging.INFO)

class KepserverAgent:
    def __init__(self, user_name, password, orgId, cluster, saveCsv=False, uploadToUnify=False):
        self.user_name = user_name
        self.password = password
        self.orgId = orgId
        self.cluster = cluster
        self.saveCsv = saveCsv
        self.uploadToUnify = uploadToUnify

    def ingest(self, file_data_list, site_name = 'default', server_name = 'default', labels = []):
        parser = _Parser(file_data_list)
        try:
            parser.process()
            dataset_csv = _converter.unifyDatasetCsv(parser.unifyDataset, site_name, server_name)
            logging.info('parsed datasets')
        except Exception as error:
            logging.error('Failed to parse dataset, error: {}'.format(error))
            raise error

        if self.uploadToUnify:
            dataset_name = utils.get_name('{}-{}-kepserver'.format(site_name, server_name))
            try:
                org_client = OrganizationClient(
                    self.user_name,
                    self.password,
                    self.orgId,
                    self.cluster)
                id = org_client.create_dataset(dataset_name, dataset_csv)['data_set_id']
                org_client.update_dataset_labels(id, labels)
                logging.info('dataset %s uploaded', dataset_name)
            except Exception as error:
                logging.error('Failed to upload and label dataset %s, error: %s', dataset_name, error)
        
        if self.saveCsv:
            try:
                file_name = '{}_{}_dataset.csv'.format(site_name, server_name)
                utils.save_csv(file_name, dataset_csv)
            except Exception as error:
                logging.error('Failed to save dataset on local, error {}'.format(error))