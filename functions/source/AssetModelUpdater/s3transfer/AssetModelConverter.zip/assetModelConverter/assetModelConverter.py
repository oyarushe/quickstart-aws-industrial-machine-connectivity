#!/usr/bin/env python3
"""
Asset Model Converter

Written by Nathan Slawson and Shahan Krakirian, 2020
"""
import collections.abc
from datetime import date, datetime
import json
import logging
import os
import sys
import tempfile
import time

import boto3
from botocore.exceptions import ClientError

from s3Utils import S3Utils
from sitewiseUtils import SitewiseUtils

log = logging.getLogger('assetModelConverter')
log.setLevel(logging.DEBUG)


class AssetModelConverter:
    """
    Asset Model Converter Class
    Combines/Parses Ignition OPC-UA Server MQTT Birth Messages, and creates Sitewise Assets/AssetModels.
    """
    def __init__(self):
        self.sitewise = boto3.client('iotsitewise')
        self.iotData = boto3.client('iot-data')

        # Messages are sent on these topics to signal completion of the conversion process.
        self.completionTopics = [
            'imc/control/sitewisemonitor',
            'imc/control/quicksight',
        ]

        # list of S3 birth object files
        self.birthObjects = []

        # Time to wait for no change in birth object count in seconds
        # self.birthObjectScanTime = 10
        self.birthObjectScanTime = int(os.environ.get('OverrideScanTime', 10))

        self.hierarchyMaxDepth = 10
        self.pHolderSuffix = ''

        # These tagKeys are used to tell when a given birth message node contains a tag.
        self.tagKeys = ["name", "timestamp", "dataType", "value"]

        self.tagAliasPrefix = '/Tag Providers/default'

        self.s3Utils = S3Utils(os.environ['IncomingBucket'])
        self.sitewiseUtils = SitewiseUtils()

        # Timestamp format to use when printing or writing messages/file/folder names
        self.timestampFormat = '%Y-%m-%d_%H-%M-%S'

        self.models = {}
        self.depthModelMap = {}
        self.assets = {}

    def updateDict(self, baseData, updateData):
        """
        Updates the baseData dictionary with the contents of updateData.
        :param baseData:
        :param updateData:
        :return:
        """
        for key, value in updateData.items():
            if isinstance(value, collections.abc.Mapping):
                baseData[key] = self.updateDict(baseData.get(key, {}), value)
            else:
                baseData[key] = value

        return baseData

    def buildStructure(self, topicList, value):
        """
        Un-squashes a path structure from the birth message name path/topic path.
        :param topicList:
        :param value:
        :return:
        """
        if not topicList:
            return value

        pathSeg = topicList.pop(0)
        childNode = self.buildStructure(topicList, value)

        return {pathSeg: childNode}

    def checkForBirthObjects(self):
        """
        Polls the incoming s3 bucket for birth node messages. Right now we are simply waiting 10 seconds
        after messages start coming in.
        :return:
        """

        lastObjectCount = 0
        lastChangeTime = time.time()

        while True:
            birthObjects = self.s3Utils.listObjects()

            if not birthObjects:
                return False

            if len(birthObjects) == lastObjectCount:
                log.info(f'Found {lastObjectCount} birth objects')
                currTime = time.time()
                if (currTime-lastChangeTime) >= self.birthObjectScanTime:
                    log.info(f'No change found in {self.birthObjectScanTime} seconds, done scanning for birth objects')
                    break
            else:
                lastChangeTime = time.time()
                lastObjectCount = len(birthObjects)

        return lastObjectCount

    def getBirthData(self):
        """
        Gets all birth objects from the incoming s3 bucket. Combines them all and stores that structure in
        self.eventData.
        :return:
        """
        birthObjects = self.s3Utils.listObjects()
        with tempfile.TemporaryDirectory() as tempFolder:
            for fileObject in birthObjects:
                birthFilename = os.path.join(tempFolder, os.path.basename(fileObject['Key']))
                self.s3Utils.downloadFile(fileObject['Key'], birthFilename)

                self.birthObjects.append(fileObject['Key'])

                with open(birthFilename, 'r', encoding='utf-8') as bFile:
                    birthData = json.load(bFile)

                    cleanedTopic = birthData['topic'].split('/')
                    cleanedTopic.pop(2)
                    cleanedTopic.pop(0)
                    # cleanedTopicString = '/'.join(cleanedTopic)

                    for metric in birthData['metrics']:
                        # Skipping metrics that are for internal ignition usage
                        if type(metric['value']) != dict or metric['value'].get('isDefinition') is None:
                            continue

                        # metricFullName = cleanedTopicString + '/' + metric['name']
                        # log.info(metricFullName)
                        mVal = metric['value']
                        if mVal['isDefinition']:
                            self.models[metric['name']] = mVal
                        else:
                            assetPath = cleanedTopic + [metric['name']]
                            assetValue = self.buildStructure(assetPath, mVal)

                            self.updateDict(self.assets, assetValue)

    def deleteBirthObjects(self):
        """
        Deletes our birth objects from S3
        :return:
        """
        for objectKey in self.birthObjects:
            self.s3Utils.deleteObject(objectKey)

    def createBaseModels(self):
        for modelName in self.models:
            # if '__modelData' in self.models[modelName]:
            #     log.info(f'Skipping existing model {modelName}')
            #     continue

            self.models[modelName]['__modelData'] = self.sitewiseUtils.createAssetModel(modelName, modelMetrics=self.models[modelName]['metrics'])

    def createPlaceholderModels(self, depthLevel=0):
        if depthLevel >= self.hierarchyMaxDepth:
            return None

        childModel = self.createPlaceholderModels(depthLevel=depthLevel+1)

        if depthLevel == 1:
            pName = '__Node' + self.pHolderSuffix
        elif depthLevel == 0:
            pName = '__Group' + self.pHolderSuffix
        else:
            pName = f'__DeviceLevel{depthLevel-1}{self.pHolderSuffix}'

        # if pName in self.models and '__modelData' in self.models[pName]:
        #     log.info(f'Skipping existing placeholder model {pName}')
        #     modelDescription = self.models[pName]['__modelData']
        # else:
        hierarchies = None
        if childModel:
            hierarchies = [{
                "name": childModel['assetModelName'],
                "childAssetModelId": childModel['assetModelId']
            }]

        modelDescription = self.sitewiseUtils.createAssetModel(modelName=pName, modelHierarchies=hierarchies)
        self.models[pName] = {'__modelData': modelDescription}
        self.models[pName]['__childModels'] = {}

        self.depthModelMap[depthLevel] = self.models[pName]

        return modelDescription

    def updatePlaceholderModels(self):
        for modelDepth in self.depthModelMap:
            modelValue = self.depthModelMap[modelDepth]
            if modelValue['__childModels']:
                hierarchies = []
                for childModelName in modelValue['__childModels']:
                    hierarchies.append({
                        "name": childModelName,
                        "childAssetModelId": self.models[childModelName]['__modelData']['assetModelId'],
                    })

                modelValue['__modelData'] = self.sitewiseUtils.updateAssetModel(
                    assetModelId=modelValue['__modelData']['assetModelId'],
                    hierarchies=hierarchies,
                )

            for hierRef in modelValue['__modelData']['assetModelHierarchies']:
                modelValue['__childModels'][hierRef['name']] = hierRef

    def getAssetNodeType(self, nodeValue):
        if 'isDefinition' in nodeValue and 'reference' in nodeValue:
            return 'asset'
        else:
            return 'folder'

    def getAssetNodeData(self, nodeValue, depthLevel):
        nodeType = self.getAssetNodeType(nodeValue)

        if nodeType == 'asset':
            baseModel = self.models[nodeValue['reference']]
        else:
            baseModel = self.depthModelMap[depthLevel]

        return nodeType, baseModel

    def createPropertyAlias(self, nodeValue):
        if nodeValue['__assetData']['assetProperties'] and nodeValue['metrics']:
            aliasMap = {}
            for metric in nodeValue['metrics']:
                tagPath = metric['properties']['ConfiguredTagPath']['value']
                aliasStr = tagPath.replace('[default]', '{aliasPrefix}/')
                aliasMap[metric['name']] = aliasStr.format(aliasPrefix=self.tagAliasPrefix)

            self.sitewiseUtils.updateAssetProperties(
                assetId=nodeValue['__assetData']['assetId'],
                assetProperties=nodeValue['__assetData']['assetProperties'],
                assetAliases=aliasMap,
            )

    def createAssetTree(self, nodeName, nodeValue, depthLevel=0, parentPath=''):
        if nodeName.startswith('__'):
            return

        nodePath = parentPath + '/' + nodeName
        nodeType, baseModel = self.getAssetNodeData(nodeValue, depthLevel)

        if '__assetData' in nodeValue:
            log.info(f'Skipping existing asset {nodePath}')
            return

        nodeAsset = self.sitewiseUtils.createAsset(
            assetName=nodePath,
            assetModelId=baseModel['__modelData']['assetModelId']
        )

        nodeValue['__assetData'] = nodeAsset

        # Process child nodes
        if nodeType == 'folder':
            for childName, childValue in nodeValue.items():
                if childName.startswith('__'):
                    continue

                self.createAssetTree(
                    nodeName=childName,
                    nodeValue=childValue,
                    depthLevel=depthLevel+1,
                    parentPath=nodePath,
                )

                if self.getAssetNodeType(childValue) == 'asset':
                    baseModel['__childModels'][childValue['reference']] = True

        self.createPropertyAlias(nodeValue)

    def associateAssetTree(self, nodeName, nodeValue, depthLevel=0, parentPath=''):
        if nodeName.startswith('__'):
            return

        nodePath = parentPath + '/' + nodeName
        nodeType, baseModel = self.getAssetNodeData(nodeValue, depthLevel)

        if nodeType != 'folder':
            return

        for childName, childValue in nodeValue.items():
            if childName.startswith('__'):
                continue

            self.associateAssetTree(
                nodeName=childName,
                nodeValue=childValue,
                depthLevel=depthLevel+1,
                parentPath=nodePath,
            )

            childNodeType, childNodeModel = self.getAssetNodeData(childValue, depthLevel+1)

            childModelName = childNodeModel['__modelData']['assetModelName']
            nodeAssetId = nodeValue['__assetData']['assetId']
            childAssetId = childValue['__assetData']['assetId']
            childHierarchyId = baseModel['__childModels'][childModelName]['id']

            self.sitewiseUtils.sitewise.associate_assets(
                assetId=nodeAssetId,
                childAssetId=childAssetId,
                hierarchyId=childHierarchyId,
            )

    def saveData(self, data, filename):
        """
        Writes a dictionary to a file as JSON.
        :param data:
        :param filename:
        :return:
        """
        with open(filename, 'w', encoding='utf-8') as dataFile:
            dataFile.write(json.dumps(data, indent=4, sort_keys=True, default=self.sitewiseUtils.jsonSerial))

    def loadData(self, filename):
        """
        Loads a JSON file into a dictionary.
        :param filename:
        :return:
        """
        with open(filename, 'r', encoding='utf-8') as dataFile:
            return json.load(dataFile)

    def publishCompletion(self):
        """
        Publish a completion message to all the self.completionTopics.
        :return:
        """
        payload = {
            'AssetModelConverter': {
                'CompletionTime': datetime.utcnow().isoformat(),
            }
        }

        for topic in self.completionTopics:
            log.info(f'Publishing completion {topic}')
            self.iotData.publish(
                topic=topic,
                qos=1,
                payload=json.dumps(payload, indent=4, sort_keys=True)
            )

    def getStateData(self):
        if os.path.exists('assets.json'):
            assetsState = self.loadData('assets.json')
            self.updateDict(self.assets, assetsState)

        if os.path.exists('models.json'):
            modelsState = self.loadData('models.json')
            self.updateDict(self.models, modelsState)

    def processEvent(self, event):
        """
        Main entry point into the class. Checks for birth messages, and starts processing them
        via createAssetModelTree().
        :param event:
        :return:
        """
        log.info(event)

        if self.checkForBirthObjects():
            self.getBirthData()
            # self.getStateData()

            try:
                self.createBaseModels()
                self.createPlaceholderModels()

                for assetGroup in self.assets:
                    self.createAssetTree(assetGroup, self.assets[assetGroup])

                self.updatePlaceholderModels()

                for assetGroup in self.assets:
                    self.associateAssetTree(assetGroup, self.assets[assetGroup])

                # self.saveData(self.assets, 'assets.json')
                # self.saveData(self.models, 'models.json')

                self.publishCompletion()

            except ClientError as cErr:
                log.exception('Failed to process birth objects')

            self.deleteBirthObjects()


def handler(event, context):
    """
    Lambda Handler
    :param event:
    :param context:
    :return:
    """
    assetModelClass = AssetModelConverter()
    assetModelClass.processEvent(event)


if __name__ == '__main__':
    """
    This is used for local execution/testing.
    """
    consoleHandler = logging.StreamHandler(sys.stdout)
    consoleHandler.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s %(levelname)s - %(message)s')
    consoleHandler.setFormatter(formatter)
    log.addHandler(consoleHandler)

    os.environ['IncomingBucket'] = 'nathanimcenv-amcincomingresource-11urj0786l9n1'
    os.environ['OverrideScanTime'] = '1'
    # os.environ['BaseTagFolder'] = 'AWS Smart Factory/AWS Smart Factory Group'
    myEvent = {}
    handler(myEvent, None)


